package com.purnadlc.platform;

import com.purnadlc.config.PurnaProfileManager;
import com.purnadlc.gui.ScrollController;
import org.junit.jupiter.api.Test;
import org.lwjgl.glfw.GLFW;

import static org.junit.jupiter.api.Assertions.*;

public class MobileCompatibilityTest {

    @Test
    void testSafeKeyNameResolutionForAndroidGlfw() {
        assertEquals("None", MobilePlatform.getKeyNameSafe(GLFW.GLFW_KEY_UNKNOWN));
        assertEquals("None", MobilePlatform.getKeyNameSafe(-1));
        assertEquals("RSHIFT", MobilePlatform.getKeyNameSafe(GLFW.GLFW_KEY_RIGHT_SHIFT));
        assertEquals("R", MobilePlatform.getKeyNameSafe(GLFW.GLFW_KEY_R));
        assertEquals("F5", MobilePlatform.getKeyNameSafe(GLFW.GLFW_KEY_F5));
        assertEquals("5", MobilePlatform.getKeyNameSafe(GLFW.GLFW_KEY_5));
        assertNotNull(MobilePlatform.getKeyNameSafe(9999));
    }

    @Test
    void testManualMobileOverride() {
        MobilePlatform.setManualOverride(Boolean.TRUE);
        assertTrue(MobilePlatform.isMobileMode());
        MobilePlatform.setManualOverride(Boolean.FALSE);
        assertFalse(MobilePlatform.isMobileMode());
        MobilePlatform.setManualOverride(null);
    }

    @Test
    void testTouchScrollClampingAndMomentum() {
        ScrollController sc = new ScrollController();
        sc.setBounds(600, 200);
        assertEquals(400, sc.getMaxScroll());

        sc.beginTouchDrag(150.0);
        assertTrue(sc.updateTouchDrag(90.0)); // dragged up by 60px -> scroll offset +60
        assertEquals(60, sc.getScrollInt());
        sc.endTouchDrag();

        // Update with fling momentum; must stay within [0, maxScroll]
        for (int i = 0; i < 60; i++) {
            sc.update(0.016f);
        }
        assertTrue(sc.getScrollInt() >= 0 && sc.getScrollInt() <= 400);
    }

    @Test
    void testAndroidSafeProfileNameSanitization() {
        assertEquals("My_Config-1", PurnaProfileManager.sanitizeName("  My_Config-1../\\:*?  "));
        assertEquals("", PurnaProfileManager.sanitizeName("///"));
    }
}
