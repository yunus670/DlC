package com.purnadlc;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.purnadlc.combat.aura.AttackAura;
import com.purnadlc.config.PurnaProfileManager;
import com.purnadlc.gui.PurnaClickGuiScreen;
import com.purnadlc.gui.hud.PurnaHudRenderer;
import com.purnadlc.gui.photo.PhotoGalleryScreen;
import com.purnadlc.gui.photo.PhotoManager;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleManager;
import com.purnadlc.module.impl.misc.ClickGuiModule;
import com.purnadlc.module.impl.movement.ElytraHelperModule;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.theme.PurnaTheme;
import com.purnadlc.visual.PurnaVisualEngine;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public final class PurnaDLC implements ClientModInitializer {
    public static final String MOD_ID = "purnadlc";
    public static final String NAME = "PurnaDLC";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    private static PurnaDLC instance;

    private PurnaTheme theme;
    private ModuleManager moduleManager;
    private PurnaProfileManager profileManager;
    private PurnaHudRenderer hudRenderer;
    private PhotoManager photoManager;
    private PurnaVisualEngine visualEngine;
    private PurnaClickGuiScreen clickGuiScreen;

    private boolean guiKeyWasDown = false;
    private final Map<Module, Boolean> moduleKeyStates = new HashMap<>();

    @Override
    public void onInitializeClient() {
        instance = this;
        this.theme = new PurnaTheme();
        this.photoManager = new PhotoManager();
        this.visualEngine = new PurnaVisualEngine();
        this.moduleManager = new ModuleManager();
        this.profileManager = new PurnaProfileManager(moduleManager, theme);
        this.hudRenderer = new PurnaHudRenderer();

        ClickGuiModule guiMod = moduleManager.getModule(ClickGuiModule.class);
        if (guiMod != null) {
            guiMod.applyMobileMode(guiMod.mobileTouchMode.getValue());
        }

        registerTickLoop();
        registerLifecycleEvents();
        registerPauseMenuButton();
        registerCommands();

        LOGGER.info("PurnaDLC Client 4K initialized for Minecraft 1.21.11 (Platform: {}).", MobilePlatform.getLauncherLabel());
    }

    private void registerPauseMenuButton() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof GameMenuScreen) {
                ButtonWidget guiBtn = ButtonWidget.builder(
                    Text.literal("PurnaDLC GUI"),
                    button -> openClickGui(client)
                ).dimensions(8, 8, 98, 22).build();
                Screens.getButtons(screen).add(guiBtn);

                ButtonWidget photoBtn = ButtonWidget.builder(
                    Text.literal("HUD Photos"),
                    button -> openPhotoGallery(client, screen)
                ).dimensions(8, 34, 98, 22).build();
                Screens.getButtons(screen).add(photoBtn);
            }
        });
    }

    private void registerLifecycleEvents() {
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            AttackAura aura = moduleManager.getModule(AttackAura.class);
            if (aura != null) aura.resetAllState();
            ElytraHelperModule eh = moduleManager.getModule(ElytraHelperModule.class);
            if (eh != null) eh.resetState(false);
        });
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            AttackAura aura = moduleManager.getModule(AttackAura.class);
            if (aura != null) aura.resetAllState();
            ElytraHelperModule eh = moduleManager.getModule(ElytraHelperModule.class);
            if (eh != null) eh.resetState(false);
        });
    }

    private void registerTickLoop() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc == null || mc.player == null || mc.getWindow() == null) {
                AttackAura aura = moduleManager.getModule(AttackAura.class);
                if (aura != null && aura.getRotationStateManager().isCombatRotationActive()) {
                    aura.resetAllState();
                }
                return;
            }

            hudRenderer.onTick(mc);
            visualEngine.onTick(mc);
            moduleManager.onClientTick();

            if (mc.currentScreen == null) {
                ClickGuiModule guiMod = moduleManager.getModule(ClickGuiModule.class);
                if (guiMod != null && guiMod.openKey.isBound()) {
                    boolean down = MobilePlatform.isKeyPressedSafe(mc.getWindow(), guiMod.openKey.getKeyCode());
                    if (down && !guiKeyWasDown) openClickGui(mc);
                    guiKeyWasDown = down;
                }

                for (Module mod : moduleManager.getAllModules()) {
                    if (mod.getKeybind().isBound()) {
                        boolean down = MobilePlatform.isKeyPressedSafe(mc.getWindow(), mod.getKeybind().getKeyCode());
                        boolean wasDown = moduleKeyStates.getOrDefault(mod, false);
                        if (down && !wasDown) mod.toggle();
                        moduleKeyStates.put(mod, down);
                    }
                }
            } else {
                guiKeyWasDown = false;
            }
        });
    }

    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            var root = ClientCommandManager.literal("purna")
                .executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.execute(() -> openClickGui(mc));
                    return 1;
                })
                .then(ClientCommandManager.literal("gui").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.execute(() -> openClickGui(mc));
                    return 1;
                }))
                .then(ClientCommandManager.literal("photo").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.execute(() -> openPhotoGallery(mc, null));
                    return 1;
                }))
                .then(ClientCommandManager.literal("photos").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.execute(() -> openPhotoGallery(mc, null));
                    return 1;
                }))
                .then(ClientCommandManager.literal("save").executes(ctx -> {
                    boolean ok = profileManager.saveCurrentProfile();
                    ctx.getSource().sendFeedback(Text.literal(ok ? "[PurnaDLC] Profile saved." : "[PurnaDLC] Save failed."));
                    return 1;
                }))
                .then(ClientCommandManager.literal("mobile").executes(ctx -> {
                    boolean next = !MobilePlatform.isMobileMode();
                    MobilePlatform.setManualOverride(next);
                    ClickGuiModule guiMod = moduleManager.getModule(ClickGuiModule.class);
                    if (guiMod != null) guiMod.mobileTouchMode.setValue(next ? "On" : "Off");
                    ctx.getSource().sendFeedback(Text.literal("[PurnaDLC] Mobile touch mode: " + (next ? "ON" : "OFF")));
                    return 1;
                }))
                .then(ClientCommandManager.literal("swap").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    ElytraHelperModule eh = moduleManager.getModule(ElytraHelperModule.class);
                    if (eh != null && mc.player != null) eh.executeChestElytraSwap(mc.player);
                    return 1;
                }))
                .then(ClientCommandManager.literal("firework").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    ElytraHelperModule eh = moduleManager.getModule(ElytraHelperModule.class);
                    if (eh != null && mc.player != null) eh.triggerFirework(mc.player);
                    return 1;
                }))
                .then(ClientCommandManager.literal("toggle")
                    .then(ClientCommandManager.argument("module", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String name = StringArgumentType.getString(ctx, "module");
                            Module mod = moduleManager.getByName(name);
                            if (mod == null) {
                                ctx.getSource().sendFeedback(Text.literal("[PurnaDLC] Module not found: " + name));
                                return 0;
                            }
                            mod.toggle();
                            ctx.getSource().sendFeedback(Text.literal("[PurnaDLC] " + mod.getName() + ": " + (mod.isEnabled() ? "ON" : "OFF")));
                            return 1;
                        })
                    )
                )
                .then(ClientCommandManager.literal("profile")
                    .then(ClientCommandManager.argument("name", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String name = StringArgumentType.getString(ctx, "name");
                            boolean ok = profileManager.loadProfile(name);
                            ctx.getSource().sendFeedback(Text.literal(ok ? "[PurnaDLC] Loaded profile: " + name : "[PurnaDLC] Profile not found: " + name));
                            return ok ? 1 : 0;
                        })
                    )
                );

            dispatcher.register(root);
            dispatcher.register(ClientCommandManager.literal("purnadlc")
                .executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.execute(() -> openClickGui(mc));
                    return 1;
                })
            );
        });
    }

    public void openClickGui(MinecraftClient mc) {
        if (mc == null || mc.currentScreen instanceof PurnaClickGuiScreen) return;
        if (clickGuiScreen == null) clickGuiScreen = new PurnaClickGuiScreen(this);
        mc.setScreen(clickGuiScreen);
    }

    public void openPhotoGallery(MinecraftClient mc, Screen parent) {
        if (mc == null) return;
        mc.setScreen(new PhotoGalleryScreen(this, parent));
    }

    public static PurnaDLC getInstance() { return instance; }
    public PurnaTheme getTheme() { return theme; }
    public ModuleManager getModuleManager() { return moduleManager; }
    public PurnaProfileManager getProfileManager() { return profileManager; }
    public PurnaHudRenderer getHudRenderer() { return hudRenderer; }
    public PhotoManager getPhotoManager() { return photoManager; }
    public PurnaVisualEngine getVisualEngine() { return visualEngine; }
}
