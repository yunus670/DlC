package com.purnadlc.mixin;

import com.purnadlc.PurnaDLC;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.module.impl.visual.ShulkerPreviewModule;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {
    @Shadow protected Slot focusedSlot;

    @Inject(method = "drawMouseoverTooltip", at = @At("TAIL"), require = 0)
    private void purnadlc$renderShulkerPreview(DrawContext ctx, int mouseX, int mouseY, CallbackInfo ci) {
        PurnaDLC client = PurnaDLC.getInstance();
        if (client == null || focusedSlot == null || !focusedSlot.hasStack()) return;
        ShulkerPreviewModule sp = client.getModuleManager().getModule(ShulkerPreviewModule.class);
        if (sp == null || !sp.isEnabled()) return;

        ItemStack stack = focusedSlot.getStack();
        ContainerComponent container = stack.get(DataComponentTypes.CONTAINER);
        if (container == null) return;

        List<ItemStack> items = container.stream().toList();
        if (items.isEmpty()) return;

        int cell = sp.compact.isEnabled() ? 17 : 19;
        int gridW = 9 * cell + 10;
        int gridH = 3 * cell + 10;
        int px = mouseX + 12;
        int py = Math.max(8, mouseY - gridH - 8);
        PurnaTheme theme = client.getTheme();

        PurnaGuiRenderer.drawRoundedRect(ctx, px, py, gridW, gridH, 7, PurnaTheme.withAlpha(theme.getMainBackground(), 0.94f));
        PurnaGuiRenderer.drawRoundedBorder(ctx, px, py, gridW, gridH, 7, theme.getPrimaryAccent());

        for (int i = 0; i < Math.min(27, items.size()); i++) {
            ItemStack item = items.get(i);
            if (item == null || item.isEmpty()) continue;
            int col = i % 9;
            int row = i / 9;
            ctx.drawItem(item, px + 5 + col * cell, py + 5 + row * cell);
        }
    }
}
