package com.purnadlc.mixin;

import com.purnadlc.PurnaDLC;
import com.purnadlc.module.impl.visual.SwingAnimationModule;
import com.purnadlc.module.impl.visual.ViewModelModule;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "applyEquipOffset", at = @At("TAIL"), require = 0)
    private void purnadlc$applyViewModel(MatrixStack matrices, Arm arm, float equipProgress, CallbackInfo ci) {
        PurnaDLC client = PurnaDLC.getInstance();
        if (client == null) return;
        ViewModelModule vm = client.getModuleManager().getModule(ViewModelModule.class);
        if (vm != null && vm.isEnabled()) {
            float sign = arm == Arm.RIGHT ? 1.0f : -1.0f;
            matrices.translate(vm.mainX.getFloat() * sign, vm.mainY.getFloat(), vm.mainZ.getFloat());
            float sc = vm.scale.getFloat();
            matrices.scale(sc, sc, sc);
        }
    }

    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true, require = 0)
    private void purnadlc$applySwingAnimation(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        PurnaDLC client = PurnaDLC.getInstance();
        if (client == null) return;
        SwingAnimationModule swing = client.getModuleManager().getModule(SwingAnimationModule.class);
        if (swing == null || !swing.isEnabled()) return;

        int sign = arm == Arm.RIGHT ? 1 : -1;
        float speed = swing.speed.getFloat();
        float p = Math.min(1.0f, swingProgress * speed);
        float sin = (float) Math.sin(p * Math.PI);
        float angle = swing.angle.getFloat();

        switch (swing.style.getValue()) {
            case "Swipe" -> {
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sign * (45.0f - sin * angle)));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-sin * angle * 1.15f));
                matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(sign * sin * 18.0f));
                ci.cancel();
            }
            case "Block" -> {
                matrices.translate(sign * -0.08f * sin, 0.05f * sin, -0.10f * sin);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-sin * angle));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sign * 32.0f * sin));
                ci.cancel();
            }
            case "Drop" -> {
                matrices.translate(0.0f, -0.22f * sin, -0.06f * sin);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-sin * angle * 1.25f));
                ci.cancel();
            }
            default -> {
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-sin * angle * 0.9f));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(sign * sin * 22.0f));
                ci.cancel();
            }
        }
    }
}
