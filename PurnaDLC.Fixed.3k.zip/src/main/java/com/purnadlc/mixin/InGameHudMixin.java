package com.purnadlc.mixin;

import com.purnadlc.PurnaDLC;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void purnadlc$onRenderHud(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        PurnaDLC client = PurnaDLC.getInstance();
        if (client == null) return;
        if (client.getVisualEngine() != null) {
            client.getVisualEngine().render(context);
        }
        if (client.getHudRenderer() != null) {
            client.getHudRenderer().render(context);
        }
    }
}
