package com.purnadlc.mixin;

import com.purnadlc.PurnaDLC;
import com.purnadlc.module.impl.visual.AspectRatioModule;
import com.purnadlc.module.impl.visual.NoRenderModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void purnadlc$onHurtCam(MatrixStack matrices, float tickProgress, CallbackInfo ci) {
        PurnaDLC client = PurnaDLC.getInstance();
        if (client == null) return;
        NoRenderModule noRender = client.getModuleManager().getModule(NoRenderModule.class);
        if (noRender != null && noRender.isEnabled() && noRender.elements.isSelected("HurtCam")) {
            ci.cancel();
        }
    }

    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true, require = 0)
    private void purnadlc$applyAspectRatio(float fovDegrees, CallbackInfoReturnable<Matrix4f> cir) {
        PurnaDLC client = PurnaDLC.getInstance();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (client == null || mc == null || mc.getWindow() == null) return;
        AspectRatioModule ar = client.getModuleManager().getModule(AspectRatioModule.class);
        if (ar != null && ar.isEnabled()) {
            int fbW = Math.max(1, mc.getWindow().getFramebufferWidth());
            int fbH = Math.max(1, mc.getWindow().getFramebufferHeight());
            float vanillaAspect = (float) fbW / fbH;
            float customAspect = Math.max(0.5f, ar.ratio.getFloat());
            Matrix4f mat = new Matrix4f(cir.getReturnValue());
            mat.scale(vanillaAspect / customAspect, 1.0f, 1.0f);
            cir.setReturnValue(mat);
        }
    }
}
