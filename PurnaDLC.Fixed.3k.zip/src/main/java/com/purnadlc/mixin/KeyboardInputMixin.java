package com.purnadlc.mixin;

import com.purnadlc.PurnaDLC;
import com.purnadlc.combat.aura.AttackAura;
import com.purnadlc.combat.aura.AttackAuraSettings;
import com.purnadlc.combat.aura.movefix.MoveFixController;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void purnadlc$applyMoveFixInput(CallbackInfo ci) {
        PurnaDLC client = PurnaDLC.getInstance();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (client == null || mc == null || mc.player == null) return;

        AttackAura aura = client.getModuleManager().getModule(AttackAura.class);
        if (aura == null || !aura.isEnabled()) return;

        AttackAuraSettings settings = aura.getSettingsBundle();
        MoveFixController moveFix = aura.getMoveFixController();
        if (!moveFix.isMoveFixActive(settings)) return;

        float cameraYaw = aura.getRotationStateManager().getCameraRotation().getYaw();
        float combatYaw = aura.getRotationStateManager().getCombatRotation().getYaw();
        this.movementVector = moveFix.correctMovementInput(
            this.movementVector, cameraYaw, combatYaw, settings.moveFixMode.getValue()
        );
    }
}
