package com.purnadlc.platform;

import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Runtime detection and safety layer for Android Java launchers
 * (Zalith Launcher, PojavLauncher, Fold Craft Launcher, MojoLauncher).
 */
public final class MobilePlatform {
    private static final boolean DETECTED_MOBILE;
    private static final String LAUNCHER_NAME;
    private static Boolean manualOverride = null;

    static {
        String detected = detectLauncher();
        LAUNCHER_NAME = detected;
        DETECTED_MOBILE = !"Desktop".equals(detected);
    }

    private MobilePlatform() {}

    private static String detectLauncher() {
        try {
            if (hasEnv("ZALITH_LAUNCHER") || hasEnv("ZALITH_DIR") || hasProp("zalith.dir")) {
                return "Zalith";
            }
            if (hasEnv("POJAV_RENDERER") || hasEnv("POJAV_ENVIRON") || hasProp("pojav.path") || hasProp("glfwstub.windowWidth")) {
                return "Pojav";
            }
            if (hasEnv("FCL_NATIVEDIR") || hasEnv("MOJO_RENDERER")) {
                return "MobileLauncher";
            }
            if (hasEnv("ANDROID_ROOT") || hasEnv("ANDROID_DATA") || hasEnv("ANDROID_STORAGE")) {
                return "Android";
            }
            String userDir = System.getProperty("user.dir", "").toLowerCase(Locale.ROOT);
            if (userDir.contains("zalith")) return "Zalith";
            if (userDir.contains("pojav") || userDir.contains("net.kdt.pojavlaunch")) return "Pojav";
            if (userDir.contains("/storage/emulated/") || userDir.contains("/data/user/")) return "Android";

            if (Files.exists(Path.of("/system/build.prop"))) {
                return "Android";
            }
        } catch (Throwable ignored) {
        }
        return "Desktop";
    }

    private static boolean hasEnv(String key) {
        String val = System.getenv(key);
        return val != null && !val.isBlank();
    }

    private static boolean hasProp(String key) {
        String val = System.getProperty(key);
        return val != null && !val.isBlank();
    }

    public static boolean isDetectedMobile() {
        return DETECTED_MOBILE;
    }

    public static boolean isMobileMode() {
        return manualOverride != null ? manualOverride : DETECTED_MOBILE;
    }

    public static void setManualOverride(Boolean enabled) {
        manualOverride = enabled;
    }

    public static String getLauncherLabel() {
        return LAUNCHER_NAME;
    }

    /**
     * Safe wrapper around Minecraft's InputUtil.isKeyPressed that guards against
     * invalid/negative keycodes or Android GLFW bridge exceptions.
     */
    public static boolean isKeyPressedSafe(Window window, int keyCode) {
        if (window == null || keyCode <= 0 || keyCode > GLFW.GLFW_KEY_LAST) {
            return false;
        }
        try {
            return InputUtil.isKeyPressed(window, keyCode);
        } catch (Throwable ignored) {
            return false;
        }
    }

    /**
     * Safe key-name resolver that never crashes on Pojav/Zalith GLFW stubs where
     * glfwGetKeyName often returns null or throws on Android keycodes.
     */
    public static String getKeyNameSafe(int code) {
        if (code <= 0 || code == GLFW.GLFW_KEY_UNKNOWN) {
            return "None";
        }
        if (code >= GLFW.GLFW_KEY_A && code <= GLFW.GLFW_KEY_Z) {
            return String.valueOf((char) ('A' + (code - GLFW.GLFW_KEY_A)));
        }
        if (code >= GLFW.GLFW_KEY_0 && code <= GLFW.GLFW_KEY_9) {
            return String.valueOf((char) ('0' + (code - GLFW.GLFW_KEY_0)));
        }
        if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F12) {
            return "F" + (code - GLFW.GLFW_KEY_F1 + 1);
        }
        String named = switch (code) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_INSERT -> "INS";
            case GLFW.GLFW_KEY_DELETE -> "DEL";
            case GLFW.GLFW_KEY_HOME -> "HOME";
            case GLFW.GLFW_KEY_END -> "END";
            case GLFW.GLFW_KEY_PAGE_UP -> "PGUP";
            case GLFW.GLFW_KEY_PAGE_DOWN -> "PGDN";
            case GLFW.GLFW_KEY_GRAVE_ACCENT -> "GRAVE";
            case GLFW.GLFW_KEY_MINUS -> "-";
            case GLFW.GLFW_KEY_EQUAL -> "=";
            case GLFW.GLFW_KEY_LEFT_BRACKET -> "[";
            case GLFW.GLFW_KEY_RIGHT_BRACKET -> "]";
            case GLFW.GLFW_KEY_SEMICOLON -> ";";
            case GLFW.GLFW_KEY_APOSTROPHE -> "'";
            case GLFW.GLFW_KEY_COMMA -> ",";
            case GLFW.GLFW_KEY_PERIOD -> ".";
            case GLFW.GLFW_KEY_SLASH -> "/";
            case GLFW.GLFW_KEY_BACKSLASH -> "\\";
            default -> null;
        };
        if (named != null) {
            return named;
        }
        try {
            String glfwName = GLFW.glfwGetKeyName(code, 0);
            if (glfwName != null && !glfwName.isBlank()) {
                return glfwName.toUpperCase(Locale.ROOT);
            }
        } catch (Throwable ignored) {
        }
        return "KEY_" + code;
    }
}
