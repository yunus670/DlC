package com.purnadlc.module;

import com.purnadlc.setting.BindSetting;
import com.purnadlc.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private final ModuleSection section;
    private boolean enabled;
    private final List<Setting<?>> settings = new ArrayList<>();
    private final BindSetting keybind;

    protected Module(String name, String description, Category category, ModuleSection section) {
        this(name, description, category, section, false);
    }

    protected Module(String name, String description, Category category, ModuleSection section, boolean defaultEnabled) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.section = section;
        this.enabled = defaultEnabled;
        this.keybind = new BindSetting("Keybind", "Toggle key for " + name, BindSetting.UNBOUND);
    }

    protected <S extends Setting<?>> S addSetting(S setting) {
        this.settings.add(setting);
        return setting;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public ModuleSection getSection() {
        return section;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean state) {
        if (this.enabled == state) {
            return;
        }
        this.enabled = state;
        if (state) {
            onEnable();
        } else {
            onDisable();
        }
    }

    public void toggle() {
        setEnabled(!this.enabled);
    }

    public BindSetting getKeybind() {
        return keybind;
    }

    public List<Setting<?>> getSettings() {
        return Collections.unmodifiableList(settings);
    }

    public boolean hasConfigurableSettings() {
        return !settings.isEmpty();
    }

    public Setting<?> findSetting(String settingName) {
        for (Setting<?> s : settings) {
            if (s.getName().equalsIgnoreCase(settingName)) {
                return s;
            }
        }
        return null;
    }

    public void onEnable() {}

    public void onDisable() {}

    public void onTick() {}
}
