package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.MultiModeSetting;

import java.util.List;

public class NoRenderModule extends Module {
    public final MultiModeSetting elements = addSetting(new MultiModeSetting(
        "Suppress", "Visual clutter elements to disable",
        List.of("HurtCam", "Fire"),
        "HurtCam", "Fire", "Fog", "Blindness", "TotemPop", "Weather"
    ));

    public NoRenderModule() {
        super("NoRender", "Suppresses obstructive camera effects and overlays", Category.VISUALS, ModuleSection.WORLD);
    }
}
