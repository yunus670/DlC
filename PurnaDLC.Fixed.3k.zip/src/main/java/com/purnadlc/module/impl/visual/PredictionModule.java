package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.MultiModeSetting;

import java.util.List;

public class PredictionModule extends Module {
    public final MultiModeSetting projectiles = addSetting(new MultiModeSetting(
        "Projectiles", "Projectile types to predict",
        List.of("Pearls", "Arrows"),
        "Pearls", "Arrows", "Potions", "Tridents"
    ));
    public final ColorSetting lineColor = addSetting(new ColorSetting("Line Color", "Trajectory arc color", 0xFF8DADDE));

    public PredictionModule() {
        super("Prediction", "Predicts landing trajectories of thrown projectiles", Category.VISUALS, ModuleSection.OVERLAY);
    }
}
