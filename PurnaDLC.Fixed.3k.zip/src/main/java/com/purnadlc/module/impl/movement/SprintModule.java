package com.purnadlc.module.impl.movement;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;

public class SprintModule extends Module {
    public final BooleanSetting keepSprint = addSetting(new BooleanSetting("Keep Sprint", "Maintain sprint velocity on attacks", true));
    public final BooleanSetting omni = addSetting(new BooleanSetting("Omni-Sprint", "Allow sprinting in all directions", false));

    public SprintModule() {
        super("Sprint", "Automatically engages sprinting while moving", Category.MOVEMENT, ModuleSection.GROUND);
    }

    @Override
    public void onTick() {
        if (mc.player != null && mc.player.forwardSpeed > 0 && !mc.player.isSneaking() && !mc.player.horizontalCollision) {
            mc.player.setSprinting(true);
        }
    }
}
