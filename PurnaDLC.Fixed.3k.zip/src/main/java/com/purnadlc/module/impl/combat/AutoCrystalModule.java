package com.purnadlc.module.impl.combat;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class AutoCrystalModule extends Module {
    public final NumberSetting placeRange = addSetting(new NumberSetting("Place Range", "Crystal placement distance", 4.5, 2.0, 6.0, 0.1));
    public final NumberSetting breakRange = addSetting(new NumberSetting("Break Range", "Crystal detonation distance", 4.5, 2.0, 6.0, 0.1));
    public final NumberSetting minDamage = addSetting(new NumberSetting("Min Damage", "Minimum target damage threshold", 6.0, 1.0, 16.0, 0.5));
    public final BooleanSetting autoSwitch = addSetting(new BooleanSetting("Auto Switch", "Swap to end crystal automatically", false));

    public AutoCrystalModule() {
        super("AutoCrystal", "Automated end crystal placement and detonation", Category.COMBAT, ModuleSection.ATTACK);
    }
}
