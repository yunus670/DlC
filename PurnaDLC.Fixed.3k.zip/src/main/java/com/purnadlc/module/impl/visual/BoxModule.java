package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.ModeSetting;

public class BoxModule extends Module {
    public final ModeSetting style = addSetting(new ModeSetting("Style", "Bounding box style", "Corner", "Full", "Corner", "3D"));
    public final BooleanSetting healthBar = addSetting(new BooleanSetting("Health Bar", "Render side health meter", true));
    public final ColorSetting color = addSetting(new ColorSetting("Color", "ESP box color", 0xFFB45AE8));

    public BoxModule() {
        super("Box", "Draws entity bounding boxes", Category.VISUALS, ModuleSection.RENDER);
    }
}
