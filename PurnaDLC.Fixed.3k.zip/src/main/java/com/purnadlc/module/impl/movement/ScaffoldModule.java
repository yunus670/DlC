package com.purnadlc.module.impl.movement;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.ModeSetting;

public class ScaffoldModule extends Module {
    public final ModeSetting rotation = addSetting(new ModeSetting("Rotation", "Block placement angle mode", "Snap", "Snap", "Smooth", "None"));
    public final BooleanSetting tower = addSetting(new BooleanSetting("Tower", "Rapidly build upward when jumping", true));

    public ScaffoldModule() {
        super("Scaffold", "Places blocks beneath the player while bridging", Category.MOVEMENT, ModuleSection.AIR_UTILITY);
    }
}
