package com.purnadlc.module.impl.combat;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class TriggerBotModule extends Module {
    public final NumberSetting delayMs = addSetting(new NumberSetting("Delay (ms)", "Extra reaction delay", 45, 0, 250, 5));
    public final BooleanSetting weaponOnly = addSetting(new BooleanSetting("Weapon Only", "Only trigger while holding sword or axe", true));

    public TriggerBotModule() {
        super("TriggerBot", "Attacks entities directly under crosshair when cooldown ready", Category.COMBAT, ModuleSection.ATTACK);
    }
}
