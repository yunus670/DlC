package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.NumberSetting;

public class BlockOverlayModule extends Module {
    public final BooleanSetting fill = addSetting(new BooleanSetting("Fill", "Fill highlighted block faces", true));
    public final BooleanSetting outline = addSetting(new BooleanSetting("Outline", "Draw block outline edges", true));
    public final ColorSetting color = addSetting(new ColorSetting("Color", "Overlay highlight color", 0xFF8DADDE));
    public final NumberSetting alpha = addSetting(new NumberSetting("Opacity", "Fill transparency", 0.30, 0.05, 0.90, 0.05));

    public BlockOverlayModule() {
        super("BlockOverlay", "Customizes the targeted block highlight box", Category.VISUALS, ModuleSection.WORLD);
    }
}
