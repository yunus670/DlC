package com.purnadlc.module.impl.combat;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.NumberSetting;

public class AimAssistModule extends Module {
    public final NumberSetting fov = addSetting(new NumberSetting("FOV", "Assist activation angle", 75, 15, 180, 5));
    public final NumberSetting smoothness = addSetting(new NumberSetting("Smoothness", "Tracking damping factor", 6.5, 1.0, 15.0, 0.5));
    public final NumberSetting range = addSetting(new NumberSetting("Range", "Maximum assist range", 4.5, 2.5, 6.0, 0.1));

    public AimAssistModule() {
        super("AimAssist", "Gently tracks nearby combat targets within FOV", Category.COMBAT, ModuleSection.COMBAT_UTILITY);
    }
}
