package com.purnadlc.module.impl.movement;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;

public class SafeWalkModule extends Module {
    public final BooleanSetting edgeSneak = addSetting(new BooleanSetting("Edge Sneak", "Tap sneak near ledges", true));

    public SafeWalkModule() {
        super("SafeWalk", "Prevents walking off block edges", Category.MOVEMENT, ModuleSection.AIR_UTILITY);
    }
}
