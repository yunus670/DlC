package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.NumberSetting;

public class AspectRatioModule extends Module {
    public final NumberSetting ratio = addSetting(new NumberSetting("Ratio", "Custom projection aspect ratio", 1.78, 0.80, 3.00, 0.02));

    public AspectRatioModule() {
        super("AspectRatio", "Overrides the camera projection aspect ratio", Category.VISUALS, ModuleSection.VIEW);
    }
}
