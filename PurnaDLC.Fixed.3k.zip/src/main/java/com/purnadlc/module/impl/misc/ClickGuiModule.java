package com.purnadlc.module.impl.misc;

import com.purnadlc.PurnaDLC;
import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.setting.BindSetting;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;
import org.lwjgl.glfw.GLFW;

public class ClickGuiModule extends Module {
    public final BindSetting openKey = addSetting(new BindSetting("Open Key", "Keyboard shortcut to open Click GUI", GLFW.GLFW_KEY_RIGHT_SHIFT));
    public final BooleanSetting crisp4k = addSetting(new BooleanSetting("4K Crisp GUI", "High-DPI 512px branding and crisp glass styling", true));
    public final BooleanSetting videoBackground = addSetting(new BooleanSetting("Video Background", "Play looping purple samurai video across ClickGUI", true));
    public final NumberSetting videoOpacity = addSetting(new NumberSetting("Video Opacity", "Opacity of the looping ClickGUI background video", 0.85, 0.15, 1.0, 0.05));
    public final ModeSetting mobileTouchMode = addSetting(new ModeSetting("Mobile Touch", "Touch optimization for Zalith/PojavLauncher", "Auto", "Auto", "On", "Off"));
    public final NumberSetting overlayOpacity = addSetting(new NumberSetting("Overlay", "World dim overlay opacity", 0.40, 0.15, 0.70, 0.05));
    public final BooleanSetting animations = addSetting(new BooleanSetting("Animations", "Enable smooth open/toggle animations", true));
    public final BooleanSetting mobileCompact = addSetting(new BooleanSetting("Force Compact", "Force single-column mobile layout", false));

    public ClickGuiModule() {
        super("ClickGui", "Configures 4K PurnaDLC Click GUI, video background, keybind, and mobile touch", Category.MISC, ModuleSection.CLIENT);
        overlayOpacity.onChange(val -> {
            if (PurnaDLC.getInstance() != null && PurnaDLC.getInstance().getTheme() != null) {
                PurnaDLC.getInstance().getTheme().setOverlayOpacity(val.floatValue());
            }
        });
        mobileTouchMode.onChange(this::applyMobileMode);
    }

    public void applyMobileMode(String mode) {
        if ("On".equalsIgnoreCase(mode)) MobilePlatform.setManualOverride(Boolean.TRUE);
        else if ("Off".equalsIgnoreCase(mode)) MobilePlatform.setManualOverride(Boolean.FALSE);
        else MobilePlatform.setManualOverride(null);
    }
}
