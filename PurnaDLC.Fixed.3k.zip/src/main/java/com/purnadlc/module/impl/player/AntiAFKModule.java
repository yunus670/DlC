package com.purnadlc.module.impl.player;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.NumberSetting;

public class AntiAFKModule extends Module {
    public final NumberSetting interval = addSetting(new NumberSetting("Interval (s)", "Seconds between subtle actions", 30, 5, 180, 5));

    public AntiAFKModule() {
        super("AntiAFK", "Performs periodic micro-actions to prevent AFK kicks", Category.PLAYER, ModuleSection.ACTIONS);
    }
}
