package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ColorSetting;
import com.purnadlc.setting.ModeSetting;
import com.purnadlc.setting.NumberSetting;

public class ShaderHandsModule extends Module {
    public final ModeSetting shaderMode = addSetting(new ModeSetting("Style", "Hand shader style", "Glow", "Glow", "Outline", "Chroma", "Glass"));
    public final ColorSetting tint = addSetting(new ColorSetting("Color", "Hand shader tint", 0xFFB45AE8));
    public final NumberSetting intensity = addSetting(new NumberSetting("Intensity", "Shader effect strength", 0.65, 0.1, 1.0, 0.05));

    public ShaderHandsModule() {
        super("ShaderHands", "Applies stylized tint/glow overlays to hands", Category.VISUALS, ModuleSection.VIEW);
    }
}
