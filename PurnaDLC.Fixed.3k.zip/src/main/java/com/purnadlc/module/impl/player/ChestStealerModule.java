package com.purnadlc.module.impl.player;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class ChestStealerModule extends Module {
    public final NumberSetting delay = addSetting(new NumberSetting("Delay (ms)", "Item transfer delay", 60, 0, 300, 10));
    public final BooleanSetting autoClose = addSetting(new BooleanSetting("Auto Close", "Close container once emptied", true));

    public ChestStealerModule() {
        super("ChestStealer", "Rapidly transfers items from open containers", Category.PLAYER, ModuleSection.INVENTORY);
    }
}
