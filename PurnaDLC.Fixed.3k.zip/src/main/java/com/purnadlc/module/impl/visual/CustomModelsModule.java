package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.EnumSetting;
import com.purnadlc.setting.NumberSetting;

public class CustomModelsModule extends Module {
    public enum ModelPreset {
        DEFAULT, DEMON, RABBIT, AMOGUS, CYBER
    }

    public final EnumSetting<ModelPreset> model = addSetting(new EnumSetting<>("Model", "Custom player model preset", ModelPreset.CYBER));
    public final BooleanSetting onlySelf = addSetting(new BooleanSetting("Only Self", "Apply model only to local player", true));
    public final NumberSetting scale = addSetting(new NumberSetting("Scale", "Model scale factor", 1.0, 0.5, 1.5, 0.05));

    public CustomModelsModule() {
        super("Custom Models", "Replaces player geometry with stylized models", Category.VISUALS, ModuleSection.VIEW);
    }
}
