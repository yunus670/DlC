package com.purnadlc.module.impl.player;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class AutoArmorModule extends Module {
    public final NumberSetting delay = addSetting(new NumberSetting("Delay (ms)", "Equip interval", 80, 0, 400, 10));
    public final BooleanSetting preferElytra = addSetting(new BooleanSetting("Keep Elytra", "Do not replace equipped elytra", true));

    public AutoArmorModule() {
        super("AutoArmor", "Equips the highest protection armor in inventory", Category.PLAYER, ModuleSection.INVENTORY);
    }
}
