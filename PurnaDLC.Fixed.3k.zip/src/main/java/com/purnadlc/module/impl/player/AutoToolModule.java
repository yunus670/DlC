package com.purnadlc.module.impl.player;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;

public class AutoToolModule extends Module {
    public final BooleanSetting swapBack = addSetting(new BooleanSetting("Swap Back", "Restore previous slot after mining", true));

    public AutoToolModule() {
        super("AutoTool", "Selects the fastest mining tool for the targeted block", Category.PLAYER, ModuleSection.ACTIONS);
    }
}
