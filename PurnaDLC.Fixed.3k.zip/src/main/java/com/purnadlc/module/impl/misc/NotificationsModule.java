package com.purnadlc.module.impl.misc;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class NotificationsModule extends Module {
    public final BooleanSetting toggleAlerts = addSetting(new BooleanSetting("Toggle Alerts", "Show notification on module toggle", true));
    public final NumberSetting duration = addSetting(new NumberSetting("Duration (s)", "Notification visible time", 2.5, 1.0, 6.0, 0.5));

    public NotificationsModule() {
        super("Notifications", "Displays client event alerts", Category.MISC, ModuleSection.MISC_UTILITY);
    }
}
