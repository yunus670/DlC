package com.purnadlc.module.impl.combat;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class AutoTotemModule extends Module {
    public final NumberSetting health = addSetting(new NumberSetting("Health", "Health threshold to equip totem", 10.0, 2.0, 20.0, 0.5));
    public final BooleanSetting fallCheck = addSetting(new BooleanSetting("Fall Check", "Equip totem on lethal fall distance", true));

    public AutoTotemModule() {
        super("AutoTotem", "Automatically moves a Totem of Undying into offhand", Category.COMBAT, ModuleSection.COMBAT_UTILITY);
    }
}
