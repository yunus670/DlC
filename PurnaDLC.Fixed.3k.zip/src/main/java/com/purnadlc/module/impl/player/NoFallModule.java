package com.purnadlc.module.impl.player;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.ModeSetting;

public class NoFallModule extends Module {
    public final ModeSetting mode = addSetting(new ModeSetting("Mode", "Fall mitigation technique", "Packet", "Packet", "Clutch", "Grim"));

    public NoFallModule() {
        super("NoFall", "Mitigates or negates incoming fall damage", Category.PLAYER, ModuleSection.ACTIONS);
    }
}
