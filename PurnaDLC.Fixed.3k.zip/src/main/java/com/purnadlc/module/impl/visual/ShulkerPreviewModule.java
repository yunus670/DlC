package com.purnadlc.module.impl.visual;

import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.setting.BooleanSetting;
import com.purnadlc.setting.NumberSetting;

public class ShulkerPreviewModule extends Module {
    public final BooleanSetting compact = addSetting(new BooleanSetting("Compact", "Compact grid spacing", true));
    public final NumberSetting scale = addSetting(new NumberSetting("Scale", "Tooltip preview scale", 1.0, 0.7, 1.5, 0.1));

    public ShulkerPreviewModule() {
        super("ShulkerPreview", "Shows shulker box inventory contents in tooltips", Category.VISUALS, ModuleSection.OVERLAY);
    }
}
