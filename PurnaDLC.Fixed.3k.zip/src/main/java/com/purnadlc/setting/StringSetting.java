package com.purnadlc.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class StringSetting extends Setting<String> {
    private final int maxLength;

    public StringSetting(String name, String description, String defaultValue, int maxLength) {
        super(name, description, defaultValue);
        this.maxLength = Math.max(1, maxLength);
        this.value = validate(defaultValue);
    }

    @Override
    protected String validate(String candidate) {
        if (candidate == null) return getDefaultValue();
        if (candidate.length() > maxLength) {
            return candidate.substring(0, maxLength);
        }
        return candidate;
    }

    public int getMaxLength() {
        return maxLength;
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(value);
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            setValue(element.getAsString());
        }
    }
}
