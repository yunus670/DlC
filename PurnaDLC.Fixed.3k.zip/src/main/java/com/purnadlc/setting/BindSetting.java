package com.purnadlc.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.purnadlc.platform.MobilePlatform;
import org.lwjgl.glfw.GLFW;

public class BindSetting extends Setting<Integer> {
    public static final int UNBOUND = GLFW.GLFW_KEY_UNKNOWN;

    public BindSetting(String name, String description, int defaultKey) {
        super(name, description, defaultKey);
    }

    public int getKeyCode() {
        return value != null ? value : UNBOUND;
    }

    public boolean isBound() {
        return getKeyCode() != UNBOUND && getKeyCode() > 0;
    }

    public String getKeyName() {
        return MobilePlatform.getKeyNameSafe(getKeyCode());
    }

    @Override
    public JsonElement toJson() {
        return new JsonPrimitive(getKeyCode());
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            setValue(element.getAsInt());
        }
    }
}
