package com.purnadlc.setting;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MultiModeSetting extends Setting<Set<String>> {
    private final List<String> options;

    public MultiModeSetting(String name, String description, List<String> defaults, String... options) {
        super(name, description, new LinkedHashSet<>(defaults));
        this.options = Collections.unmodifiableList(Arrays.asList(options));
        this.value = validate(new LinkedHashSet<>(defaults));
    }

    @Override
    protected Set<String> validate(Set<String> candidate) {
        Set<String> valid = new LinkedHashSet<>();
        if (candidate != null) {
            for (String opt : options) {
                for (String c : candidate) {
                    if (opt.equalsIgnoreCase(c)) {
                        valid.add(opt);
                    }
                }
            }
        }
        return valid;
    }

    public List<String> getOptions() {
        return options;
    }

    public boolean isSelected(String option) {
        return value.contains(option);
    }

    public void toggleOption(String option) {
        if (!options.contains(option)) return;
        Set<String> updated = new LinkedHashSet<>(value);
        if (updated.contains(option)) {
            updated.remove(option);
        } else {
            updated.add(option);
        }
        setValue(updated);
    }

    public String getSummaryText() {
        if (value.isEmpty()) return "None";
        if (value.size() == options.size()) return "All";
        if (value.size() <= 2) return String.join(", ", value);
        return value.size() + " selected";
    }

    @Override
    public JsonElement toJson() {
        JsonArray arr = new JsonArray();
        for (String s : value) {
            arr.add(s);
        }
        return arr;
    }

    @Override
    public void fromJson(JsonElement element) {
        if (element != null && element.isJsonArray()) {
            Set<String> loaded = new LinkedHashSet<>();
            for (JsonElement e : element.getAsJsonArray()) {
                if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isString()) {
                    loaded.add(e.getAsString());
                }
            }
            setValue(loaded);
        }
    }
}
