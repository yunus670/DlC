package com.purnadlc.combat.aura;

import net.minecraft.entity.LivingEntity;

public final class CombatState {
    private LivingEntity primaryTarget;
    private int lastTargetEntityId = -1;
    private boolean targetSwitchedThisTick;
    private boolean attackedThisTick;
    private boolean criticalOpportunityReady;
    private boolean shieldBreakActive;
    private double targetDistance;
    private long activeWorldIdentityHash;
    private long totalAttacksExecuted;

    public LivingEntity getPrimaryTarget() { return primaryTarget; }

    public void setPrimaryTarget(LivingEntity target) {
        int nextId = target != null ? target.getId() : -1;
        this.targetSwitchedThisTick = (nextId != this.lastTargetEntityId);
        this.primaryTarget = target;
        this.lastTargetEntityId = nextId;
    }

    public boolean hasTarget() {
        return primaryTarget != null && primaryTarget.isAlive() && !primaryTarget.isRemoved();
    }

    public boolean didTargetSwitchThisTick() { return targetSwitchedThisTick; }
    public boolean hasAttackedThisTick() { return attackedThisTick; }

    public void setAttackedThisTick(boolean attackedThisTick) {
        this.attackedThisTick = attackedThisTick;
        if (attackedThisTick) this.totalAttacksExecuted++;
    }

    public boolean isCriticalOpportunityReady() { return criticalOpportunityReady; }
    public void setCriticalOpportunityReady(boolean v) { this.criticalOpportunityReady = v; }
    public boolean isShieldBreakActive() { return shieldBreakActive; }
    public void setShieldBreakActive(boolean v) { this.shieldBreakActive = v; }
    public double getTargetDistance() { return targetDistance; }
    public void setTargetDistance(double d) { this.targetDistance = d; }
    public long getActiveWorldIdentityHash() { return activeWorldIdentityHash; }
    public void setActiveWorldIdentityHash(long hash) { this.activeWorldIdentityHash = hash; }
    public long getTotalAttacksExecuted() { return totalAttacksExecuted; }

    public void beginTick() {
        this.attackedThisTick = false;
        this.targetSwitchedThisTick = false;
    }

    public void reset() {
        this.primaryTarget = null;
        this.lastTargetEntityId = -1;
        this.targetSwitchedThisTick = false;
        this.attackedThisTick = false;
        this.criticalOpportunityReady = false;
        this.shieldBreakActive = false;
        this.targetDistance = 0.0;
    }
}
