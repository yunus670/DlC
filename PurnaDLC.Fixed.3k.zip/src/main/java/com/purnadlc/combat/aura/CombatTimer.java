package com.purnadlc.combat.aura;

public final class CombatTimer {
    private long lastMarkMs;

    public CombatTimer() {
        this.lastMarkMs = nowMs();
    }

    public long nowMs() {
        return System.nanoTime() / 1_000_000L;
    }

    public void reset() {
        this.lastMarkMs = nowMs();
    }

    public void setLastMarkMs(long customMarkMs) {
        this.lastMarkMs = customMarkMs;
    }

    public long elapsedMs() {
        return Math.max(0L, nowMs() - lastMarkMs);
    }

    public boolean hasElapsed(long delayMs) {
        return delayMs <= 0L || elapsedMs() >= delayMs;
    }

    public boolean hasElapsed(long delayMs, long currentTimeMs) {
        return delayMs <= 0L || (currentTimeMs - lastMarkMs) >= delayMs;
    }
}
