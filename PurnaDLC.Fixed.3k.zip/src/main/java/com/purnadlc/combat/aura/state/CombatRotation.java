package com.purnadlc.combat.aura.state;

import com.purnadlc.combat.aura.RotationMath;

public final class CombatRotation {
    private float yaw;
    private float pitch;
    private float prevYaw;
    private float prevPitch;
    private boolean active;

    public void set(float newYaw, float newPitch) {
        float safeYaw = RotationMath.normalizeYaw(newYaw);
        float safePitch = RotationMath.clampPitch(newPitch);
        if (!active) {
            this.prevYaw = safeYaw;
            this.prevPitch = safePitch;
        } else {
            this.prevYaw = this.yaw;
            this.prevPitch = this.pitch;
        }
        this.yaw = safeYaw;
        this.pitch = safePitch;
        this.active = true;
    }

    public void syncFromCamera(CameraRotation camera) {
        if (camera == null || !camera.isInitialized()) return;
        this.yaw = camera.getYaw();
        this.pitch = camera.getPitch();
        this.prevYaw = this.yaw;
        this.prevPitch = this.pitch;
    }

    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
    public float getPrevYaw() { return prevYaw; }
    public float getPrevPitch() { return prevPitch; }
    public float getLastYawDelta() { return RotationMath.yawDifference(prevYaw, yaw); }
    public float getLastPitchDelta() { return RotationMath.pitchDifference(prevPitch, pitch); }
    public boolean isActive() { return active; }
    public void deactivate() { this.active = false; }

    public void reset() {
        this.yaw = 0.0f;
        this.pitch = 0.0f;
        this.prevYaw = 0.0f;
        this.prevPitch = 0.0f;
        this.active = false;
    }
}
