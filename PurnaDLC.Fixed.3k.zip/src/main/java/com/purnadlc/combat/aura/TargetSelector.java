package com.purnadlc.combat.aura;

import java.util.Comparator;
import java.util.List;

public final class TargetSelector {
    public record TargetCandidate<T>(
        T entity, int id, double distance, float effectiveHealth, float rotationDifference, int categoryWeight
    ) {}

    private int activeTargetId = -1;
    private int multiCycleIndex = 0;
    private final CombatTimer switchTimer = new CombatTimer();

    public <T> TargetCandidate<T> select(List<TargetCandidate<T>> candidates,
                                         AttackAuraSettings.TargetMode mode,
                                         AttackAuraSettings.TargetPriority priority,
                                         boolean multiTargetEnabled,
                                         long switchDelayMs) {
        if (candidates == null || candidates.isEmpty()) {
            activeTargetId = -1;
            multiCycleIndex = 0;
            return null;
        }

        candidates.sort(comparatorFor(priority));

        if (mode == AttackAuraSettings.TargetMode.SINGLE && !multiTargetEnabled) {
            TargetCandidate<T> current = findById(candidates, activeTargetId);
            if (current != null) return current;
            TargetCandidate<T> chosen = candidates.get(0);
            activeTargetId = chosen.id();
            switchTimer.reset();
            return chosen;
        }

        if (mode == AttackAuraSettings.TargetMode.MULTI || multiTargetEnabled) {
            if (candidates.size() == 1) {
                TargetCandidate<T> only = candidates.get(0);
                activeTargetId = only.id();
                return only;
            }
            if (switchTimer.hasElapsed(switchDelayMs)) {
                multiCycleIndex = (multiCycleIndex + 1) % candidates.size();
                switchTimer.reset();
            } else if (multiCycleIndex >= candidates.size()) {
                multiCycleIndex = 0;
            }
            TargetCandidate<T> chosen = candidates.get(multiCycleIndex);
            activeTargetId = chosen.id();
            return chosen;
        }

        TargetCandidate<T> best = candidates.get(0);
        TargetCandidate<T> current = findById(candidates, activeTargetId);
        if (current != null && current.id() != best.id() && !switchTimer.hasElapsed(switchDelayMs)) {
            return current;
        }
        if (best.id() != activeTargetId) {
            activeTargetId = best.id();
            switchTimer.reset();
        }
        return best;
    }

    public void notifyAttackedTarget() { switchTimer.reset(); }

    public void reset() {
        activeTargetId = -1;
        multiCycleIndex = 0;
        switchTimer.reset();
    }

    private static <T> TargetCandidate<T> findById(List<TargetCandidate<T>> candidates, int id) {
        if (id < 0) return null;
        for (TargetCandidate<T> c : candidates) {
            if (c.id() == id) return c;
        }
        return null;
    }

    private static <T> Comparator<TargetCandidate<T>> comparatorFor(AttackAuraSettings.TargetPriority priority) {
        return switch (priority) {
            case LOWEST_HEALTH -> Comparator
                .comparingDouble((TargetCandidate<T> c) -> c.effectiveHealth())
                .thenComparingDouble(TargetCandidate::distance)
                .thenComparingInt(TargetCandidate::id);
            case SMALLEST_ROTATION_DIFFERENCE -> Comparator
                .comparingDouble((TargetCandidate<T> c) -> c.rotationDifference())
                .thenComparingDouble(TargetCandidate::distance)
                .thenComparingInt(TargetCandidate::id);
            case HIGHEST_PRIORITY -> Comparator
                .comparingInt((TargetCandidate<T> c) -> -c.categoryWeight())
                .thenComparingDouble(TargetCandidate::distance)
                .thenComparingDouble(TargetCandidate::effectiveHealth)
                .thenComparingInt(TargetCandidate::id);
            case CLOSEST_DISTANCE -> Comparator
                .comparingDouble((TargetCandidate<T> c) -> c.distance())
                .thenComparingDouble(TargetCandidate::rotationDifference)
                .thenComparingInt(TargetCandidate::id);
        };
    }
}
