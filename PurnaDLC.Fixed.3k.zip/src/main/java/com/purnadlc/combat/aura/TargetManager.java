package com.purnadlc.combat.aura;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.List;

public final class TargetManager {
    private final FOVCalculator fovCalculator;
    private final TargetSelector selector;
    private final List<TargetSelector.TargetCandidate<LivingEntity>> candidateBuffer = new ArrayList<>(32);

    public TargetManager(FOVCalculator fovCalculator, TargetSelector selector) {
        this.fovCalculator = fovCalculator;
        this.selector = selector;
    }

    public LivingEntity acquireTarget(ClientWorld world, ClientPlayerEntity player,
                                      float viewerYaw, float viewerPitch,
                                      AttackAuraSettings settings, CombatState combatState) {
        candidateBuffer.clear();
        if (world == null || player == null || !player.isAlive()) {
            combatState.setPrimaryTarget(null);
            combatState.setTargetDistance(0.0);
            return null;
        }

        boolean requireFov = settings.fovCheck.isEnabled();
        boolean requireVis = settings.visibilityCheck.isEnabled();

        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (!isEntityEligible(player, living, settings)) continue;

            FOVCalculator.FovEvaluation eval = fovCalculator.evaluateEntity(
                player, world, viewerYaw, viewerPitch, living, settings
            );
            if (!eval.isValid(requireFov, requireVis)) continue;

            float effectiveHealth = living.getHealth() + living.getAbsorptionAmount();
            int categoryWeight = computeCategoryWeight(living);
            candidateBuffer.add(new TargetSelector.TargetCandidate<>(
                living, living.getId(), eval.distance(), effectiveHealth, eval.combinedAngle(), categoryWeight
            ));
        }

        TargetSelector.TargetCandidate<LivingEntity> chosen = selector.select(
            candidateBuffer,
            settings.targetMode.getValue(),
            settings.targetPriority.getValue(),
            settings.multiTarget.isEnabled(),
            settings.targetSwitching.getInt()
        );

        if (chosen == null) {
            combatState.setPrimaryTarget(null);
            combatState.setTargetDistance(0.0);
            return null;
        }

        combatState.setPrimaryTarget(chosen.entity());
        combatState.setTargetDistance(chosen.distance());
        return chosen.entity();
    }

    public boolean isEntityEligible(ClientPlayerEntity player, LivingEntity entity, AttackAuraSettings settings) {
        if (entity == null || entity == player) return false;
        if (!entity.isAlive() || entity.isRemoved() || entity.getHealth() <= 0.0f) return false;
        if (entity instanceof ArmorStandEntity) return false;
        if (entity.isInvulnerable()) return false;
        if (entity.isInvisible() && !settings.invisibleEntities.isEnabled()) return false;
        if (entity instanceof PlayerEntity otherPlayer) {
            if (otherPlayer.isSpectator() || otherPlayer.isCreative()) return false;
            return settings.players.isEnabled();
        }
        if (entity instanceof Monster) return settings.hostileMobs.isEnabled();
        if (entity instanceof PassiveEntity) return settings.passiveMobs.isEnabled();
        return settings.hostileMobs.isEnabled();
    }

    public boolean isStillValidForAttack(ClientWorld world, ClientPlayerEntity player,
                                         LivingEntity target, float viewerYaw, float viewerPitch,
                                         AttackAuraSettings settings) {
        if (!isEntityEligible(player, target, settings)) return false;
        FOVCalculator.FovEvaluation eval = fovCalculator.evaluateEntity(
            player, world, viewerYaw, viewerPitch, target, settings
        );
        boolean rangeOk = !settings.rangeValidation.isEnabled() || eval.inRange();
        boolean fovOk = !settings.fovCheck.isEnabled() || (eval.inHorizontalFov() && eval.inVerticalFov() && eval.inCombinedFov());
        boolean visOk = !settings.visibilityCheck.isEnabled() || eval.visible();
        return rangeOk && fovOk && visOk;
    }

    public void reset() {
        candidateBuffer.clear();
        selector.reset();
    }

    public TargetSelector getSelector() { return selector; }

    private static int computeCategoryWeight(LivingEntity entity) {
        if (entity instanceof PlayerEntity) return 100;
        if (entity instanceof Monster) return 60;
        return 20;
    }
}
