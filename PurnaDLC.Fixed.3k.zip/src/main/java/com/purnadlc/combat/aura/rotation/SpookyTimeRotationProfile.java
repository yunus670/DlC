package com.purnadlc.combat.aura.rotation;

import com.purnadlc.combat.aura.AttackAuraSettings;
import com.purnadlc.combat.aura.RotationMath;
import com.purnadlc.combat.aura.RotationProfile;

public final class SpookyTimeRotationProfile implements RotationProfile {
    private float smoothedYawError = 0.0f;
    private float smoothedPitchError = 0.0f;
    private float switchBlend = 1.0f;

    @Override
    public String getName() { return "SpookyTime"; }

    @Override
    public RotationResult computeNext(RotationInput input, AttackAuraSettings settings) {
        if (input.targetSwitched()) onTargetChanged();

        float pitchLimit = settings.pitchLimit.getFloat();
        float yawDiff = RotationMath.yawDifference(input.currentYaw(), input.targetYaw());
        float pitchDiff = RotationMath.pitchDifference(
            RotationMath.clampPitch(input.currentPitch(), pitchLimit),
            RotationMath.clampPitch(input.targetPitch(), pitchLimit)
        );

        double safeDist = Double.isFinite(input.targetDistance()) ? Math.max(0.5, Math.min(8.0, input.targetDistance())) : 3.0;
        float distanceFactor = (float) (1.28 - 0.11 * Math.min(5.0, safeDist));

        if (switchBlend < 1.0f) {
            switchBlend = Math.min(1.0f, switchBlend + 0.22f);
        }
        float ease = RotationMath.transitionEase(switchBlend);

        float alpha = Math.max(0.12f, 1.0f - settings.rotationSmoothing.getFloat() * 0.68f);
        smoothedYawError = smoothedYawError + (yawDiff - smoothedYawError) * alpha;
        smoothedPitchError = smoothedPitchError + (pitchDiff - smoothedPitchError) * (alpha * 0.82f);

        float maxCap = settings.maxRotationSpeed.getFloat();
        float yawLimit = Math.min(maxCap, settings.horizontalSpeed.getFloat() * distanceFactor);
        float pitchLimitStep = Math.min(maxCap, settings.verticalSpeed.getFloat() * (0.85f + 0.15f * distanceFactor));

        float baseInterp = settings.interpolation.getFloat();
        float yawInterp = Math.min(1.0f, baseInterp * (0.55f + 0.45f * ease) * distanceFactor);
        float pitchInterp = Math.min(1.0f, baseInterp * 0.78f * (0.50f + 0.50f * ease));

        float yawStep = clamp(smoothedYawError * yawInterp, -yawLimit, yawLimit);
        float pitchStep = clamp(smoothedPitchError * pitchInterp, -pitchLimitStep, pitchLimitStep);

        if (Math.signum(yawStep) == Math.signum(yawDiff) && Math.abs(yawStep) > Math.abs(yawDiff)) yawStep = yawDiff;
        if (Math.signum(pitchStep) == Math.signum(pitchDiff) && Math.abs(pitchStep) > Math.abs(pitchDiff)) pitchStep = pitchDiff;

        return new RotationResult(
            RotationMath.normalizeYaw(input.currentYaw() + yawStep),
            RotationMath.clampPitch(input.currentPitch() + pitchStep, pitchLimit)
        );
    }

    @Override
    public void onTargetChanged() {
        this.switchBlend = 0.0f;
        this.smoothedYawError *= 0.25f;
        this.smoothedPitchError *= 0.25f;
    }

    @Override
    public void reset() {
        this.smoothedYawError = 0.0f;
        this.smoothedPitchError = 0.0f;
        this.switchBlend = 1.0f;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
