package com.purnadlc.combat.aura;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public final class AttackController {
    private final CriticalManager criticalManager;
    private final ShieldBreaker shieldBreaker;
    private final TargetManager targetManager;
    private final CombatTimer attackTimer = new CombatTimer();
    private long lastAttackTick = -1L;

    public AttackController(CriticalManager criticalManager, ShieldBreaker shieldBreaker, TargetManager targetManager) {
        this.criticalManager = criticalManager;
        this.shieldBreaker = shieldBreaker;
        this.targetManager = targetManager;
    }

    public boolean canProceedWithCycle(long currentTick, float cooldownProgress,
                                       float minCooldown, long attackDelayMs, long elapsedSinceAttackMs) {
        if (currentTick == lastAttackTick) return false;
        if (cooldownProgress < minCooldown) return false;
        return elapsedSinceAttackMs >= Math.max(0L, attackDelayMs);
    }

    public boolean tryAttack(MinecraftClient mc, ClientWorld world, ClientPlayerEntity player,
                             LivingEntity target, float activeYaw, float activePitch,
                             long currentTick, AttackAuraSettings settings, CombatState state) {
        if (mc == null || mc.interactionManager == null || world == null || player == null || target == null) return false;
        if (state.hasAttackedThisTick() || currentTick == lastAttackTick) return false;

        if (!targetManager.isStillValidForAttack(world, player, target, activeYaw, activePitch, settings)) {
            shieldBreaker.restoreSlotIfNeeded(player, settings);
            return false;
        }

        float cooldownProgress = player.getAttackCooldownProgress(0.5f);
        if (!canProceedWithCycle(currentTick, cooldownProgress,
                settings.attackCooldown.getFloat(), settings.attackDelay.getInt(), attackTimer.elapsedMs())) {
            return false;
        }

        boolean breakingShield = shieldBreaker.prepareIfNeeded(player, target, settings);
        state.setShieldBreakActive(breakingShield);

        CriticalManager.CriticalVerdict critVerdict = criticalManager.evaluate(player, settings);
        boolean critReady = (critVerdict == CriticalManager.CriticalVerdict.READY);
        state.setCriticalOpportunityReady(critReady);

        if (!breakingShield && critVerdict != CriticalManager.CriticalVerdict.NOT_REQUIRED && !critReady) {
            return false;
        }

        int preHurtTime = target.hurtTime;
        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);

        lastAttackTick = currentTick;
        attackTimer.reset();
        state.setAttackedThisTick(true);
        targetManager.getSelector().notifyAttackedTarget();

        if (critReady) criticalManager.recordCriticalAttack();
        if (breakingShield) {
            shieldBreaker.onShieldStrikeExecuted(player, settings);
            state.setShieldBreakActive(false);
        }

        return target.hurtTime >= preHurtTime;
    }

    public void markSimulatedAttack(long tick) {
        this.lastAttackTick = tick;
        this.attackTimer.reset();
    }

    public void reset(ClientPlayerEntity player, AttackAuraSettings settings) {
        this.lastAttackTick = -1L;
        this.attackTimer.reset();
        this.criticalManager.reset();
        this.shieldBreaker.reset(player, settings);
    }
}
