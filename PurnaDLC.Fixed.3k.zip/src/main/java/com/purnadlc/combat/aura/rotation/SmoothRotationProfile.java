package com.purnadlc.combat.aura.rotation;

import com.purnadlc.combat.aura.AttackAuraSettings;
import com.purnadlc.combat.aura.RotationMath;
import com.purnadlc.combat.aura.RotationProfile;

public final class SmoothRotationProfile implements RotationProfile {
    private float yawVelocity = 0.0f;
    private float pitchVelocity = 0.0f;
    private float transitionProgress = 1.0f;

    @Override
    public String getName() { return "Smooth"; }

    @Override
    public RotationResult computeNext(RotationInput input, AttackAuraSettings settings) {
        if (input.targetSwitched()) onTargetChanged();

        float pitchLimit = settings.pitchLimit.getFloat();
        float yawDiff = RotationMath.yawDifference(input.currentYaw(), input.targetYaw());
        float pitchDiff = RotationMath.pitchDifference(
            RotationMath.clampPitch(input.currentPitch(), pitchLimit),
            RotationMath.clampPitch(input.targetPitch(), pitchLimit)
        );

        if (transitionProgress < 1.0f) {
            transitionProgress = Math.min(1.0f, transitionProgress + 0.18f);
        }
        float transitionFactor = 0.35f + 0.65f * RotationMath.transitionEase(transitionProgress);

        float smoothness = settings.smoothness.getFloat();
        float interp = settings.interpolation.getFloat();
        float secondarySmooth = settings.rotationSmoothing.getFloat();
        float accel = settings.acceleration.getFloat();
        float maxSpeed = settings.maxRotationSpeed.getFloat();
        float maxYawStep = Math.min(maxSpeed, settings.horizontalSpeed.getFloat());
        float maxPitchStep = Math.min(maxSpeed, settings.verticalSpeed.getFloat());

        float gain = Math.max(0.05f, (1.0f - smoothness * 0.72f) * interp * transitionFactor);
        float desiredYawVel = Math.abs(yawDiff) < 0.15f ? 0.0f : clamp(yawDiff * gain, -maxYawStep, maxYawStep);
        float desiredPitchVel = Math.abs(pitchDiff) < 0.15f ? 0.0f : clamp(pitchDiff * gain, -maxPitchStep, maxPitchStep);

        yawVelocity = approach(yawVelocity, desiredYawVel, accel);
        pitchVelocity = approach(pitchVelocity, desiredPitchVel, accel * 0.85f);

        float damp = 1.0f - secondarySmooth * 0.55f;
        float appliedYawStep = clamp(yawVelocity * damp, -maxYawStep, maxYawStep);
        float appliedPitchStep = clamp(pitchVelocity * damp, -maxPitchStep, maxPitchStep);

        if (Math.abs(appliedYawStep) > Math.abs(yawDiff)) {
            appliedYawStep = yawDiff;
            yawVelocity *= 0.5f;
        }
        if (Math.abs(appliedPitchStep) > Math.abs(pitchDiff)) {
            appliedPitchStep = pitchDiff;
            pitchVelocity *= 0.5f;
        }

        return new RotationResult(
            RotationMath.normalizeYaw(input.currentYaw() + appliedYawStep),
            RotationMath.clampPitch(input.currentPitch() + appliedPitchStep, pitchLimit)
        );
    }

    @Override
    public void onTargetChanged() {
        this.transitionProgress = 0.0f;
        this.yawVelocity *= 0.4f;
        this.pitchVelocity *= 0.4f;
    }

    @Override
    public void reset() {
        this.yawVelocity = 0.0f;
        this.pitchVelocity = 0.0f;
        this.transitionProgress = 1.0f;
    }

    private static float approach(float current, float target, float maxDelta) {
        float diff = target - current;
        if (diff > maxDelta) return current + maxDelta;
        if (diff < -maxDelta) return current - maxDelta;
        return target;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
