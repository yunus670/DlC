package com.purnadlc.combat.aura.state;

import net.minecraft.client.network.ClientPlayerEntity;

public final class RotationStateManager {
    private static final long STALE_TICK_THRESHOLD = 4L;

    private final CameraRotation cameraRotation = new CameraRotation();
    private final CombatRotation combatRotation = new CombatRotation();
    private final ServerRotationState serverState = new ServerRotationState();

    private long tickCounter = 0L;

    public void beginTick(ClientPlayerEntity player) {
        tickCounter++;
        if (player == null) {
            reset();
            return;
        }
        cameraRotation.updateFromPlayer(player.getYaw(), player.getPitch());
        if (!combatRotation.isActive()) {
            combatRotation.syncFromCamera(cameraRotation);
        }
        if (serverState.isStale(tickCounter, STALE_TICK_THRESHOLD)) {
            serverState.recordSync(cameraRotation.getYaw(), cameraRotation.getPitch(), tickCounter);
        }
    }

    public void beginTickManual(float cameraYaw, float cameraPitch) {
        tickCounter++;
        cameraRotation.updateFromPlayer(cameraYaw, cameraPitch);
        if (!combatRotation.isActive()) {
            combatRotation.syncFromCamera(cameraRotation);
        }
    }

    public void commitCombatRotation(float yaw, float pitch, boolean applyToCamera, ClientPlayerEntity player) {
        combatRotation.set(yaw, pitch);
        serverState.recordSync(combatRotation.getYaw(), combatRotation.getPitch(), tickCounter);
        if (applyToCamera && player != null) {
            player.setYaw(combatRotation.getYaw());
            player.setPitch(combatRotation.getPitch());
            cameraRotation.updateFromPlayer(player.getYaw(), player.getPitch());
        }
    }

    public void onTargetLost() {
        combatRotation.deactivate();
        if (cameraRotation.isInitialized()) {
            combatRotation.syncFromCamera(cameraRotation);
            serverState.recordSync(cameraRotation.getYaw(), cameraRotation.getPitch(), tickCounter);
        }
    }

    public void reset() {
        cameraRotation.reset();
        combatRotation.reset();
        serverState.reset();
        tickCounter = 0L;
    }

    public CameraRotation getCameraRotation() { return cameraRotation; }
    public CombatRotation getCombatRotation() { return combatRotation; }
    public ServerRotationState getServerState() { return serverState; }
    public boolean isCombatRotationActive() { return combatRotation.isActive(); }
    public float getEffectiveYaw() { return combatRotation.isActive() ? combatRotation.getYaw() : cameraRotation.getYaw(); }
    public float getEffectivePitch() { return combatRotation.isActive() ? combatRotation.getPitch() : cameraRotation.getPitch(); }
    public long getTickCounter() { return tickCounter; }
}
