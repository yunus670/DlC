package com.purnadlc.animation;

public final class AnimatedValue {
    private float current;
    private float target;
    private float speed;

    public AnimatedValue(float initial, float speedPerSecond) {
        this.current = initial;
        this.target = initial;
        this.speed = Math.max(0.5f, speedPerSecond);
    }

    public void setTarget(float target) {
        this.target = target;
    }

    public void snapTo(float value) {
        this.current = value;
        this.target = value;
    }

    public float update(float deltaSeconds) {
        float dt = Math.max(0.0001f, Math.min(0.1f, deltaSeconds));
        float diff = target - current;
        if (Math.abs(diff) < 0.0005f) {
            current = target;
            return current;
        }
        float factor = 1f - (float) Math.exp(-speed * dt);
        current += diff * factor;
        return current;
    }

    public float get() {
        return current;
    }

    public float getTarget() {
        return target;
    }

    public boolean isSettled() {
        return Math.abs(target - current) < 0.002f;
    }
}
