package com.purnadlc.animation;

public final class Easing {
    private Easing() {}

    public static float easeOutCubic(float t) {
        t = clamp01(t);
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    public static float easeInOutCubic(float t) {
        t = clamp01(t);
        return t < 0.5f
            ? 4f * t * t * t
            : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }

    public static float easeOutQuint(float t) {
        t = clamp01(t);
        return 1f - (float) Math.pow(1f - t, 5);
    }

    public static float clamp01(float t) {
        return Math.max(0f, Math.min(1f, t));
    }
}
