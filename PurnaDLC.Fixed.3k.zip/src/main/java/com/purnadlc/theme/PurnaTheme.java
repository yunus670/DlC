package com.purnadlc.theme;

import java.util.LinkedHashMap;
import java.util.Map;

public final class PurnaTheme {
    // Base PurnaDLC specification palette
    public static final int DEFAULT_MAIN_BG          = 0xF0101114;
    public static final int DEFAULT_SECONDARY_BG     = 0xF217191F;
    public static final int DEFAULT_CARD_BG          = 0xFF20232B;
    public static final int DEFAULT_CARD_HOVER       = 0xFF292C36;
    public static final int DEFAULT_SELECTED_CAT     = 0xFF38283F;
    public static final int DEFAULT_PRIMARY_PURPLE   = 0xFFB45AE8;
    public static final int DEFAULT_SECONDARY_PURPLE = 0xFF8C6BEA;
    public static final int DEFAULT_PRIMARY_TEXT     = 0xFFE6E6EB;
    public static final int DEFAULT_SECONDARY_TEXT   = 0xFF92939F;
    public static final int DEFAULT_DISABLED_TEXT    = 0xFF656671;
    public static final int DEFAULT_DISABLED_TOGGLE  = 0xFF50515B;
    public static final int DEFAULT_ENABLED_TOGGLE   = 0xFF8DADDE;
    public static final int DEFAULT_BORDER           = 0xFF30323B;

    // Recommended geometry constants (logical pixels)
    public static final int BASE_WINDOW_WIDTH   = 640;
    public static final int BASE_WINDOW_HEIGHT  = 440;
    public static final int SIDEBAR_WIDTH       = 118;
    public static final int TOOLBAR_HEIGHT      = 46;
    public static final int WINDOW_RADIUS       = 12;
    public static final int CARD_RADIUS         = 7;
    public static final int BUTTON_RADIUS       = 5;
    public static final int ROW_HEIGHT          = 32;
    public static final int ROW_GAP             = 5;
    public static final int CARD_PADDING_X      = 10;

    private String activePreset = "Purna Purple";
    private int mainBackground = DEFAULT_MAIN_BG;
    private int secondaryBackground = DEFAULT_SECONDARY_BG;
    private int cardBackground = DEFAULT_CARD_BG;
    private int cardHover = DEFAULT_CARD_HOVER;
    private int selectedCategory = DEFAULT_SELECTED_CAT;
    private int primaryAccent = DEFAULT_PRIMARY_PURPLE;
    private int secondaryAccent = DEFAULT_SECONDARY_PURPLE;
    private int primaryText = DEFAULT_PRIMARY_TEXT;
    private int secondaryText = DEFAULT_SECONDARY_TEXT;
    private int disabledText = DEFAULT_DISABLED_TEXT;
    private int disabledToggle = DEFAULT_DISABLED_TOGGLE;
    private int enabledToggle = DEFAULT_ENABLED_TOGGLE;
    private int borderColor = DEFAULT_BORDER;
    private float overlayOpacity = 0.40f;

    public record ThemePreset(
        String name,
        int primaryAccent,
        int secondaryAccent,
        int selectedCategory,
        int enabledToggle
    ) {}

    private static final Map<String, ThemePreset> PRESETS = new LinkedHashMap<>();
    static {
        PRESETS.put("Purna Purple", new ThemePreset("Purna Purple", 0xFFB45AE8, 0xFF8C6BEA, 0xFF38283F, 0xFF8DADDE));
        PRESETS.put("Midnight Indigo", new ThemePreset("Midnight Indigo", 0xFF6E7BF2, 0xFF5060D8, 0xFF252A44, 0xFF7FA6F5));
        PRESETS.put("Crimson Dusk", new ThemePreset("Crimson Dusk", 0xFFE85A7C, 0xFFB84569, 0xFF3D222D, 0xFFE07A96));
        PRESETS.put("Emerald Slate", new ThemePreset("Emerald Slate", 0xFF47C992, 0xFF349E73, 0xFF1F3830, 0xFF6DD4AA));
        PRESETS.put("Frost Cyan", new ThemePreset("Frost Cyan", 0xFF56C2E8, 0xFF4B8FE2, 0xFF1E3240, 0xFF7FD4F2));
    }

    public Map<String, ThemePreset> getPresets() {
        return PRESETS;
    }

    public void applyPreset(String presetName) {
        ThemePreset preset = PRESETS.get(presetName);
        if (preset == null) return;
        this.activePreset = preset.name();
        this.primaryAccent = preset.primaryAccent();
        this.secondaryAccent = preset.secondaryAccent();
        this.selectedCategory = preset.selectedCategory();
        this.enabledToggle = preset.enabledToggle();
    }

    public String getActivePreset() { return activePreset; }
    public int getMainBackground() { return mainBackground; }
    public int getSecondaryBackground() { return secondaryBackground; }
    public int getCardBackground() { return cardBackground; }
    public int getCardHover() { return cardHover; }
    public int getSelectedCategory() { return selectedCategory; }
    public int getPrimaryAccent() { return primaryAccent; }
    public int getSecondaryAccent() { return secondaryAccent; }
    public int getPrimaryText() { return primaryText; }
    public int getSecondaryText() { return secondaryText; }
    public int getDisabledText() { return disabledText; }
    public int getDisabledToggle() { return disabledToggle; }
    public int getEnabledToggle() { return enabledToggle; }
    public int getBorderColor() { return borderColor; }
    public float getOverlayOpacity() { return overlayOpacity; }

    public void setPrimaryAccent(int argb) {
        this.primaryAccent = (0xFF << 24) | (argb & 0xFFFFFF);
        this.selectedCategory = lerpColor(0xFF17191F, this.primaryAccent, 0.24f);
        this.activePreset = "Custom";
    }

    public void setSecondaryAccent(int argb) {
        this.secondaryAccent = (0xFF << 24) | (argb & 0xFFFFFF);
        this.activePreset = "Custom";
    }

    public void setEnabledToggle(int argb) {
        this.enabledToggle = (0xFF << 24) | (argb & 0xFFFFFF);
        this.activePreset = "Custom";
    }

    public void setOverlayOpacity(float opacity) {
        this.overlayOpacity = Math.max(0.15f, Math.min(0.75f, opacity));
    }

    public static int withAlpha(int argb, float alphaMultiplier) {
        float clamped = Math.max(0f, Math.min(1f, alphaMultiplier));
        int baseAlpha = (argb >>> 24) & 0xFF;
        int outAlpha = Math.round(baseAlpha * clamped);
        return (outAlpha << 24) | (argb & 0x00FFFFFF);
    }

    public static int overrideAlpha(int rgb, int alpha255) {
        int a = Math.max(0, Math.min(255, alpha255));
        return (a << 24) | (rgb & 0x00FFFFFF);
    }

    public static int lerpColor(int fromArgb, int toArgb, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a1 = (fromArgb >>> 24) & 0xFF, r1 = (fromArgb >> 16) & 0xFF, g1 = (fromArgb >> 8) & 0xFF, b1 = fromArgb & 0xFF;
        int a2 = (toArgb >>> 24) & 0xFF,   r2 = (toArgb >> 16) & 0xFF,   g2 = (toArgb >> 8) & 0xFF,   b2 = toArgb & 0xFF;
        int a = Math.round(a1 + (a2 - a1) * t);
        int r = Math.round(r1 + (r2 - r1) * t);
        int g = Math.round(g1 + (g2 - g1) * t);
        int b = Math.round(b1 + (b2 - b1) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
