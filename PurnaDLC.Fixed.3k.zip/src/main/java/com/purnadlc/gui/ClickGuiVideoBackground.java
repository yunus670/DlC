package com.purnadlc.gui;

import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

public final class ClickGuiVideoBackground {
    public static final int FRAME_COUNT = 24;
    public static final int FRAME_W = 640;
    public static final int FRAME_H = 440;
    private static final double LOOP_DURATION_MS = 4800.0;

    private static final Identifier[] FRAME_IDS = new Identifier[FRAME_COUNT];
    public static final Identifier LOGO_4K_ID = Identifier.of("purnadlc", "textures/gui/logo_4k.png");

    static {
        for (int i = 0; i < FRAME_COUNT; i++) {
            FRAME_IDS[i] = Identifier.of("purnadlc", String.format("textures/gui/bg/frame_%02d.png", i));
        }
    }

    private ClickGuiVideoBackground() {}

    public static Identifier getCurrentFrameId() {
        long now = System.currentTimeMillis();
        double progress = (now % (long) LOOP_DURATION_MS) / LOOP_DURATION_MS;
        int index = (int) Math.floor(progress * FRAME_COUNT) % FRAME_COUNT;
        if (index < 0) index = 0;
        return FRAME_IDS[index];
    }

    public static boolean render(DrawContext ctx, int x, int y, int w, int h, float alpha, float videoOpacity) {
        if (w <= 0 || h <= 0 || alpha <= 0.01f || videoOpacity <= 0.01f) return false;
        int a = Math.max(0, Math.min(255, Math.round(255f * alpha * videoOpacity)));
        int tint = (a << 24) | 0x00FFFFFF;
        boolean drawn = GuiTextureBlitter.drawCoverTexture(ctx, getCurrentFrameId(), x, y, w, h, FRAME_W, FRAME_H, tint);
        if (drawn) {
            int veilAlpha = Math.round(86f * alpha);
            ctx.fill(x, y, x + w, y + h, PurnaTheme.overrideAlpha(0x0B0C10, veilAlpha));
        }
        return drawn;
    }

    public static boolean draw4kLogo(DrawContext ctx, int x, int y, int size, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(255f * Math.max(0f, Math.min(1f, alpha)))));
        return GuiTextureBlitter.drawFullTexture(ctx, LOGO_4K_ID, x, y, size, size, (a << 24) | 0x00FFFFFF);
    }
}
