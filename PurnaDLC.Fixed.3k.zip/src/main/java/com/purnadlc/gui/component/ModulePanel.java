package com.purnadlc.gui.component;

import com.purnadlc.animation.PurnaAnimationManager;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.gui.ScrollController;
import com.purnadlc.module.Category;
import com.purnadlc.module.Module;
import com.purnadlc.module.ModuleManager;
import com.purnadlc.module.ModuleSection;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.Consumer;

public final class ModulePanel {
    private static final double TOUCH_DRAG_SLOP = 7.0;

    private final ScrollController leftScroll = new ScrollController();
    private final ScrollController rightScroll = new ScrollController();

    private record EntryHitbox(Module module, int x, int y, int w, int h, boolean searchMode) {}
    private final List<EntryHitbox> hitboxes = new ArrayList<>();

    private record PresetHitbox(String name, int x, int y, int w, int h) {}
    private final List<PresetHitbox> presetHitboxes = new ArrayList<>();
    private int opacityBarX, opacityBarY, opacityBarW;
    private boolean draggingOpacity = false;

    private final List<String> ircMessages = new ArrayList<>(List.of(
        "[System] Connected to PurnaDLC local channel #general",
        "[PurnaBot] Type a message below and tap Send or Enter.",
        "[PurnaBot] Mobile tip: use Pause -> PurnaDLC GUI or /purna."
    ));
    private String ircInput = "";
    private boolean ircFocused = false;
    private int ircInputX, ircInputY, ircInputW, ircInputH;
    private int ircSendX, ircSendY, ircSendW, ircSendH;

    private int areaX, areaY, areaW, areaH;
    private int leftColX, leftColW, rightColX, rightColW;
    private boolean singleColumnMode = false;

    // Touch scroll vs tap disambiguation state
    private ScrollController activeTouchScroll = null;
    private EntryHitbox pendingTapEntry = null;
    private ModuleEntry.ClickAction pendingTapAction = ModuleEntry.ClickAction.NONE;
    private double pressStartX = 0.0;
    private double pressStartY = 0.0;
    private boolean movedPastSlop = false;

    public void onCategoryChanged() {
        leftScroll.reset();
        rightScroll.reset();
        ircFocused = false;
        clearPendingTap();
    }

    public boolean hasTextFocus() { return ircFocused; }

    public void render(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                       int mouseX, int mouseY, boolean allowHover, float alpha,
                       Category category, String searchQuery, boolean forceCompact,
                       ModuleManager modules, PurnaTheme theme, PurnaAnimationManager anim) {
        this.areaX = x;
        this.areaY = y;
        this.areaW = w;
        this.areaH = h;
        hitboxes.clear();
        presetHitboxes.clear();

        leftScroll.update(anim.getDeltaSeconds());
        rightScroll.update(anim.getDeltaSeconds());

        float contentAlpha = alpha * anim.getCategoryAlpha();

        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            renderSearchResults(ctx, tr, x, y, w, h, mouseX, mouseY, allowHover, contentAlpha, searchQuery, modules, theme, anim);
            return;
        }
        if (category == Category.THEME) {
            renderThemeView(ctx, tr, x, y, w, h, mouseX, mouseY, contentAlpha, theme);
            return;
        }
        if (category == Category.IRC) {
            renderIrcView(ctx, tr, x, y, w, h, mouseX, mouseY, contentAlpha, theme);
            return;
        }

        boolean mobile = MobilePlatform.isMobileMode();
        int pad = 12;
        int colGap = 12;
        singleColumnMode = forceCompact || w < (mobile ? 410 : 360);

        if (singleColumnMode) {
            leftColX = x + pad;
            leftColW = Math.max(40, w - pad * 2);
            rightColX = leftColX;
            rightColW = leftColW;

            Map<ModuleSection, List<Module>> combined = new LinkedHashMap<>();
            combined.putAll(modules.getSectionsForColumn(category, ModuleSection.ColumnSide.LEFT));
            combined.putAll(modules.getSectionsForColumn(category, ModuleSection.ColumnSide.RIGHT));

            renderColumn(ctx, tr, combined, leftColX, y + 6, leftColW, Math.max(20, h - 14),
                mouseX, mouseY, allowHover, contentAlpha, leftScroll, theme, anim, true);
        } else {
            leftColW = Math.max(40, (w - pad * 2 - colGap) / 2);
            rightColW = Math.max(40, w - pad * 2 - colGap - leftColW);
            leftColX = x + pad;
            rightColX = leftColX + leftColW + colGap;

            Map<ModuleSection, List<Module>> leftSections = modules.getSectionsForColumn(category, ModuleSection.ColumnSide.LEFT);
            Map<ModuleSection, List<Module>> rightSections = modules.getSectionsForColumn(category, ModuleSection.ColumnSide.RIGHT);

            renderColumn(ctx, tr, leftSections, leftColX, y + 6, leftColW, Math.max(20, h - 14),
                mouseX, mouseY, allowHover, contentAlpha, leftScroll, theme, anim, mobile);
            renderColumn(ctx, tr, rightSections, rightColX, y + 6, rightColW, Math.max(20, h - 14),
                mouseX, mouseY, allowHover, contentAlpha, rightScroll, theme, anim, mobile);
        }
    }

    private void renderColumn(DrawContext ctx, TextRenderer tr, Map<ModuleSection, List<Module>> sections,
                              int colX, int colY, int colW, int colH,
                              int mouseX, int mouseY, boolean allowHover, float alpha,
                              ScrollController scroll, PurnaTheme theme, PurnaAnimationManager anim,
                              boolean largeTouchTargets) {
        int rowH = largeTouchTargets ? 38 : PurnaTheme.ROW_HEIGHT;
        int rowGap = largeTouchTargets ? 6 : PurnaTheme.ROW_GAP;
        int totalH = 0;
        for (Map.Entry<ModuleSection, List<Module>> entry : sections.entrySet()) {
            totalH += 16;
            totalH += entry.getValue().size() * (rowH + rowGap);
            totalH += 8;
        }
        scroll.setBounds(totalH, colH);

        boolean scissored = PurnaGuiRenderer.safeEnableScissor(ctx, colX - 2, colY, colX + colW + 2, colY + colH);
        int cursorY = colY - scroll.getScrollInt();

        for (Map.Entry<ModuleSection, List<Module>> entry : sections.entrySet()) {
            if (cursorY + 14 >= colY && cursorY <= colY + colH) {
                ctx.drawText(tr, entry.getKey().getTitle(), colX + 2, cursorY + 2,
                    PurnaTheme.withAlpha(theme.getSecondaryText(), alpha), false);
            }
            cursorY += 16;

            for (Module mod : entry.getValue()) {
                if (cursorY + rowH >= colY - 4 && cursorY <= colY + colH + 4) {
                    boolean rowCanHover = allowHover && PurnaGuiRenderer.isHovered(mouseX, mouseY, colX, colY, colW, colH);
                    ModuleEntry.render(ctx, tr, mod, colX, cursorY, colW, rowH,
                        mouseX, mouseY, rowCanHover, alpha, theme, anim, null);
                    if (cursorY + rowH > colY && cursorY < colY + colH) {
                        hitboxes.add(new EntryHitbox(mod, colX, cursorY, colW, rowH, false));
                    }
                }
                cursorY += rowH + rowGap;
            }
            cursorY += 8;
        }
        if (scissored) ctx.disableScissor();

        if (scroll.canScroll()) {
            int trackH = colH - 4;
            int thumbH = Math.max(22, Math.round(trackH * ((float) colH / Math.max(1, totalH))));
            int thumbY = colY + 2 + Math.round((trackH - thumbH) * scroll.getScrollRatio());
            int barW = largeTouchTargets ? 3 : 2;
            PurnaGuiRenderer.drawRoundedRect(ctx, colX + colW + 2, thumbY, barW, thumbH, 1,
                PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha * 0.65f));
        }
    }

    private void renderSearchResults(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                                     int mouseX, int mouseY, boolean allowHover, float alpha,
                                     String query, ModuleManager modules, PurnaTheme theme, PurnaAnimationManager anim) {
        List<Module> results = modules.search(query);
        int pad = 12;
        int colX = x + pad;
        int colY = y + 8;
        int colW = Math.max(40, w - pad * 2);
        int colH = Math.max(20, h - 16);

        ctx.drawText(tr, "Search Results (" + results.size() + ")", colX + 2, colY,
            PurnaTheme.withAlpha(theme.getSecondaryText(), alpha), false);

        int listTop = colY + 16;
        int listH = Math.max(20, colH - 16);

        if (results.isEmpty()) {
            PurnaGuiRenderer.drawRoundedRect(ctx, colX, listTop + 8, colW, 44, 7,
                PurnaTheme.withAlpha(theme.getCardBackground(), alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, "No modules match \"" + query.trim() + "\"",
                colX + 12, listTop + 26, colW - 24, PurnaTheme.withAlpha(theme.getSecondaryText(), alpha));
            return;
        }

        int rowH = MobilePlatform.isMobileMode() ? 40 : 36;
        int totalH = results.size() * (rowH + 5);
        leftScroll.setBounds(totalH, listH);

        boolean scissored = PurnaGuiRenderer.safeEnableScissor(ctx, colX - 2, listTop, colX + colW + 2, listTop + listH);
        int cursorY = listTop - leftScroll.getScrollInt();
        for (Module mod : results) {
            if (cursorY + rowH >= listTop - 4 && cursorY <= listTop + listH + 4) {
                boolean rowHover = allowHover && PurnaGuiRenderer.isHovered(mouseX, mouseY, colX, listTop, colW, listH);
                String sub = mod.getCategory().getDisplayName() + " > " + mod.getSection().getTitle();
                ModuleEntry.render(ctx, tr, mod, colX, cursorY, colW, rowH,
                    mouseX, mouseY, rowHover, alpha, theme, anim, sub);
                hitboxes.add(new EntryHitbox(mod, colX, cursorY, colW, rowH, true));
            }
            cursorY += rowH + 5;
        }
        if (scissored) ctx.disableScissor();
    }

    private void renderThemeView(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                                 int mouseX, int mouseY, float alpha, PurnaTheme theme) {
        int pad = 14;
        int cx = x + pad;
        int cy = y + 10;
        int cw = Math.max(80, w - pad * 2);

        ctx.drawText(tr, "Color Presets (" + MobilePlatform.getLauncherLabel() + ")", cx, cy,
            PurnaTheme.withAlpha(theme.getSecondaryText(), alpha), false);
        cy += 16;

        int cols = cw < 270 ? 1 : 2;
        int cardW = cols == 1 ? cw : Math.max(100, (cw - 10) / 2);
        int cardH = 38;
        int idx = 0;
        for (PurnaTheme.ThemePreset preset : theme.getPresets().values()) {
            int col = idx % cols;
            int row = idx / cols;
            int px = cx + col * (cardW + 10);
            int py = cy + row * (cardH + 8);
            boolean active = preset.name().equalsIgnoreCase(theme.getActivePreset());
            boolean hov = PurnaGuiRenderer.isHovered(mouseX, mouseY, px, py, cardW, cardH);

            int bg = active ? theme.getSelectedCategory() : (hov ? theme.getCardHover() : theme.getCardBackground());
            PurnaGuiRenderer.drawRoundedRect(ctx, px, py, cardW, cardH, 7, PurnaTheme.withAlpha(bg, alpha));
            PurnaGuiRenderer.drawRoundedBorder(ctx, px, py, cardW, cardH, 7,
                PurnaTheme.withAlpha(active ? preset.primaryAccent() : theme.getBorderColor(), alpha));

            PurnaGuiRenderer.drawCircle(ctx, px + 16, py + cardH / 2, 7, PurnaTheme.withAlpha(preset.primaryAccent(), alpha));
            PurnaGuiRenderer.drawCircle(ctx, px + 26, py + cardH / 2, 5, PurnaTheme.withAlpha(preset.enabledToggle(), alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, preset.name(), px + 38, py + 15, cardW - 46,
                PurnaTheme.withAlpha(theme.getPrimaryText(), alpha));

            presetHitboxes.add(new PresetHitbox(preset.name(), px, py, cardW, cardH));
            idx++;
        }

        int rowsUsed = (idx + cols - 1) / cols;
        int sliderCardY = cy + rowsUsed * (cardH + 8) + 12;
        if (sliderCardY + 46 < y + h) {
            PurnaGuiRenderer.drawRoundedRect(ctx, cx, sliderCardY, cw, 44, 7,
                PurnaTheme.withAlpha(theme.getCardBackground(), alpha));
            String pct = Math.round(theme.getOverlayOpacity() * 100) + "%";
            ctx.drawText(tr, "World Overlay Darkness", cx + 10, sliderCardY + 8,
                PurnaTheme.withAlpha(theme.getPrimaryText(), alpha), false);
            ctx.drawText(tr, pct, cx + cw - 10 - tr.getWidth(pct), sliderCardY + 8,
                PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha), false);

            opacityBarX = cx + 10;
            opacityBarY = sliderCardY + 26;
            opacityBarW = Math.max(20, cw - 20);
            float norm = (theme.getOverlayOpacity() - 0.15f) / 0.60f;
            PurnaGuiRenderer.drawRoundedRect(ctx, opacityBarX, opacityBarY, opacityBarW, 6, 3,
                PurnaTheme.withAlpha(theme.getDisabledToggle(), alpha));
            PurnaGuiRenderer.drawRoundedRect(ctx, opacityBarX, opacityBarY, Math.max(4, Math.round(opacityBarW * norm)), 6, 3,
                PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha));
        }
    }

    private void renderIrcView(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                               int mouseX, int mouseY, float alpha, PurnaTheme theme) {
        int pad = 12;
        int cx = x + pad;
        int cy = y + 10;
        int cw = Math.max(80, w - pad * 2);
        int chatH = Math.max(40, h - 54);

        PurnaGuiRenderer.drawRoundedRect(ctx, cx, cy, cw, chatH, 7,
            PurnaTheme.withAlpha(theme.getCardBackground(), alpha));
        boolean scissored = PurnaGuiRenderer.safeEnableScissor(ctx, cx + 4, cy + 4, cx + cw - 4, cy + chatH - 4);
        int lineY = cy + 10;
        for (String msg : ircMessages) {
            int col = msg.startsWith("[System]") ? theme.getPrimaryAccent()
                    : (msg.startsWith("[PurnaBot]") ? theme.getEnabledToggle() : theme.getPrimaryText());
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, msg, cx + 10, lineY, cw - 20, PurnaTheme.withAlpha(col, alpha));
            lineY += 14;
        }
        if (scissored) ctx.disableScissor();

        ircSendW = 42;
        ircSendH = 26;
        ircSendX = cx + cw - ircSendW;
        ircSendY = cy + chatH + 8;

        ircInputX = cx;
        ircInputY = ircSendY;
        ircInputW = Math.max(40, cw - ircSendW - 6);
        ircInputH = 26;

        PurnaGuiRenderer.drawRoundedRect(ctx, ircInputX, ircInputY, ircInputW, ircInputH, 6,
            PurnaTheme.withAlpha(theme.getCardBackground(), alpha));
        PurnaGuiRenderer.drawRoundedBorder(ctx, ircInputX, ircInputY, ircInputW, ircInputH, 6,
            PurnaTheme.withAlpha(ircFocused ? theme.getPrimaryAccent() : theme.getBorderColor(), alpha));
        String txt = ircInput.isEmpty() ? "Message #general..." : ircInput + (ircFocused && ((System.currentTimeMillis() / 500) % 2 == 0) ? "|" : "");
        PurnaGuiRenderer.drawTrimmedText(ctx, tr, txt, ircInputX + 10, ircInputY + 9, ircInputW - 18,
            PurnaTheme.withAlpha(ircInput.isEmpty() ? theme.getDisabledText() : theme.getPrimaryText(), alpha));

        boolean sendHover = PurnaGuiRenderer.isHovered(mouseX, mouseY, ircSendX, ircSendY, ircSendW, ircSendH);
        PurnaGuiRenderer.drawRoundedRect(ctx, ircSendX, ircSendY, ircSendW, ircSendH, 6,
            PurnaTheme.withAlpha(sendHover ? theme.getPrimaryAccent() : theme.getSelectedCategory(), alpha));
        int stw = tr.getWidth("Send");
        ctx.drawText(tr, "Send", ircSendX + (ircSendW - stw) / 2, ircSendY + 9,
            PurnaTheme.withAlpha(theme.getPrimaryText(), alpha), false);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button,
                                Category category, PurnaTheme theme,
                                Consumer<Module> onOpenSettings, Consumer<Module> onJumpToModule) {
        clearPendingTap();
        if (!PurnaGuiRenderer.isHovered(mouseX, mouseY, areaX, areaY, areaW, areaH)) {
            ircFocused = false;
            return false;
        }

        if (category == Category.THEME && button == 0) {
            for (PresetHitbox ph : presetHitboxes) {
                if (PurnaGuiRenderer.isHovered(mouseX, mouseY, ph.x, ph.y, ph.w, ph.h)) {
                    theme.applyPreset(ph.name);
                    return true;
                }
            }
            if (PurnaGuiRenderer.isHovered(mouseX, mouseY, opacityBarX - 4, opacityBarY - 10, opacityBarW + 8, 26)) {
                draggingOpacity = true;
                updateOpacity(mouseX, theme);
                return true;
            }
            return true;
        }

        if (category == Category.IRC && button == 0) {
            if (PurnaGuiRenderer.isHovered(mouseX, mouseY, ircSendX, ircSendY, ircSendW, ircSendH)) {
                sendIrcMessage();
                return true;
            }
            ircFocused = PurnaGuiRenderer.isHovered(mouseX, mouseY, ircInputX, ircInputY, ircInputW, ircInputH);
            return true;
        }

        // Right-click opens settings immediately
        if (button == 1) {
            for (EntryHitbox hb : hitboxes) {
                if (PurnaGuiRenderer.isHovered(mouseX, mouseY, hb.x, hb.y, hb.w, hb.h)) {
                    if (onOpenSettings != null) onOpenSettings.accept(hb.module);
                    return true;
                }
            }
            return false;
        }

        if (button == 0) {
            // Prepare touch scroll & deferred tap so dragging finger over cards scrolls instead of accidentally toggling
            activeTouchScroll = (!singleColumnMode && mouseX >= rightColX) ? rightScroll : leftScroll;
            activeTouchScroll.beginTouchDrag(mouseY);
            pressStartX = mouseX;
            pressStartY = mouseY;
            movedPastSlop = false;

            for (EntryHitbox hb : hitboxes) {
                ModuleEntry.ClickAction action = ModuleEntry.hitTest(mouseX, mouseY, button, hb.x, hb.y, hb.w, hb.h, hb.searchMode);
                if (action != ModuleEntry.ClickAction.NONE) {
                    pendingTapEntry = hb;
                    pendingTapAction = action;
                    return true;
                }
            }
            return true;
        }
        return false;
    }

    public boolean mouseDragged(double mouseX, double mouseY, PurnaTheme theme) {
        if (draggingOpacity) {
            updateOpacity(mouseX, theme);
            return true;
        }
        if (activeTouchScroll != null) {
            double dist = Math.hypot(mouseX - pressStartX, mouseY - pressStartY);
            if (dist >= TOUCH_DRAG_SLOP) {
                movedPastSlop = true;
                pendingTapEntry = null;
                pendingTapAction = ModuleEntry.ClickAction.NONE;
            }
            if (movedPastSlop || !MobilePlatform.isMobileMode()) {
                return activeTouchScroll.updateTouchDrag(mouseY);
            }
            return true;
        }
        return false;
    }

    public void mouseReleased(Consumer<Module> onOpenSettings, Consumer<Module> onJumpToModule) {
        draggingOpacity = false;
        if (activeTouchScroll != null) {
            activeTouchScroll.endTouchDrag();
            activeTouchScroll = null;
        }
        if (!movedPastSlop && pendingTapEntry != null && pendingTapAction != ModuleEntry.ClickAction.NONE) {
            if (pendingTapAction == ModuleEntry.ClickAction.TOGGLE) {
                pendingTapEntry.module.toggle();
            } else if (pendingTapAction == ModuleEntry.ClickAction.SETTINGS) {
                if (onOpenSettings != null) onOpenSettings.accept(pendingTapEntry.module);
            } else if (pendingTapAction == ModuleEntry.ClickAction.JUMP) {
                if (onJumpToModule != null) onJumpToModule.accept(pendingTapEntry.module);
            }
        }
        clearPendingTap();
    }

    private void clearPendingTap() {
        pendingTapEntry = null;
        pendingTapAction = ModuleEntry.ClickAction.NONE;
        movedPastSlop = false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double verticalAmount) {
        if (!PurnaGuiRenderer.isHovered(mouseX, mouseY, areaX, areaY, areaW, areaH)) return false;
        if (!singleColumnMode && mouseX >= rightColX) {
            rightScroll.onWheel(verticalAmount);
        } else {
            leftScroll.onWheel(verticalAmount);
        }
        return true;
    }

    public boolean keyPressed(int keyCode) {
        if (!ircFocused) return false;
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            ircFocused = false;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !ircInput.isEmpty()) {
            ircInput = ircInput.substring(0, ircInput.length() - 1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            sendIrcMessage();
            return true;
        }
        return true;
    }

    private void sendIrcMessage() {
        String trimmed = ircInput.trim();
        if (!trimmed.isEmpty()) {
            MinecraftClient mc = MinecraftClient.getInstance();
            String user = (mc != null && mc.getSession() != null) ? mc.getSession().getUsername() : "You";
            ircMessages.add("[" + user + "] " + trimmed);
            if (ircMessages.size() > 24) ircMessages.remove(0);
            ircInput = "";
        }
    }

    public boolean charTyped(char chr) {
        if (!ircFocused || Character.isISOControl(chr)) return false;
        if (ircInput.length() < 64) ircInput += chr;
        return true;
    }

    private void updateOpacity(double mouseX, PurnaTheme theme) {
        float ratio = (float) Math.max(0.0, Math.min(1.0, (mouseX - opacityBarX) / Math.max(1.0, opacityBarW)));
        theme.setOverlayOpacity(0.15f + ratio * 0.60f);
    }
}
