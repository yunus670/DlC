package com.purnadlc.gui.component;

import com.purnadlc.config.PurnaProfileManager;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public final class PurnaToolbar {
    private boolean searchActive = false;
    private String searchQuery = "";

    private boolean profileMenuOpen = false;
    private boolean namingNewProfile = false;
    private boolean renamingProfile = false;
    private String profileInput = "";
    private String pendingDeleteProfile = null;
    private String statusFlash = "";
    private long statusFlashUntil = 0L;

    private int profileBtnX, profileBtnY, profileBtnW, profileBtnH;
    private int photosBtnX, photosBtnY, photosBtnW, photosBtnH;
    private int closeBtnX, closeBtnY, closeBtnW, closeBtnH;
    private int searchBtnX, searchBtnY, searchBtnW, searchBtnH;
    private int searchBoxX, searchBoxY, searchBoxW, searchBoxH;
    private int clearSearchX, clearSearchY, clearSearchW, clearSearchH;
    private int menuX, menuY, menuW, menuH;
    private int confirmBtnX, confirmBtnY, confirmBtnW, confirmBtnH;

    public String getSearchQuery() { return searchQuery; }
    public boolean isSearchFocused() { return searchActive; }
    public boolean isProfileMenuOpen() { return profileMenuOpen; }
    public boolean hasTextFocus() { return searchActive || namingNewProfile || renamingProfile; }

    public void closePopups() {
        profileMenuOpen = false;
        namingNewProfile = false;
        renamingProfile = false;
        pendingDeleteProfile = null;
    }

    public void clearSearch() {
        searchQuery = "";
        searchActive = false;
    }

    public void render(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                       int mouseX, int mouseY, float alpha, PurnaTheme theme, PurnaProfileManager profiles) {
        ctx.fill(x + 8, y + h - 1, x + w - 8, y + h, PurnaTheme.withAlpha(theme.getBorderColor(), alpha * 0.65f));

        boolean mobile = MobilePlatform.isMobileMode();
        int ctrlH = mobile ? 26 : 24;
        int ctrlY = y + (h - ctrlH) / 2;

        // Top-right Close button
        closeBtnW = ctrlH;
        closeBtnH = ctrlH;
        closeBtnX = x + w - closeBtnW - 10;
        closeBtnY = ctrlY;
        boolean closeHover = PurnaGuiRenderer.isHovered(mouseX, mouseY, closeBtnX, closeBtnY, closeBtnW, closeBtnH);
        PurnaGuiRenderer.drawRoundedRect(ctx, closeBtnX, closeBtnY, closeBtnW, closeBtnH, 6,
            PurnaTheme.withAlpha(closeHover ? 0xFF9E324C : theme.getCardBackground(), alpha * 0.80f));
        PurnaGuiRenderer.drawRoundedBorder(ctx, closeBtnX, closeBtnY, closeBtnW, closeBtnH, 6,
            PurnaTheme.withAlpha(theme.getBorderColor(), alpha));
        int xTw = tr.getWidth("x");
        ctx.drawText(tr, "x", closeBtnX + (closeBtnW - xTw) / 2, closeBtnY + (closeBtnH - tr.fontHeight) / 2,
            PurnaTheme.withAlpha(closeHover ? 0xFFFFFFFF : theme.getSecondaryText(), alpha), false);

        // Profile selector pill on left
        profileBtnW = Math.min(120, Math.max(82, w / 4));
        profileBtnH = ctrlH;
        profileBtnX = x + 10;
        profileBtnY = ctrlY;

        boolean profHover = PurnaGuiRenderer.isHovered(mouseX, mouseY, profileBtnX, profileBtnY, profileBtnW, profileBtnH);
        int profBg = profHover || profileMenuOpen ? theme.getCardHover() : theme.getCardBackground();
        PurnaGuiRenderer.drawRoundedRect(ctx, profileBtnX, profileBtnY, profileBtnW, profileBtnH, 6,
            PurnaTheme.withAlpha(profBg, alpha * 0.80f));
        PurnaGuiRenderer.drawRoundedBorder(ctx, profileBtnX, profileBtnY, profileBtnW, profileBtnH, 6,
            PurnaTheme.withAlpha(profileMenuOpen ? theme.getPrimaryAccent() : theme.getBorderColor(), alpha));

        PurnaGuiRenderer.drawProfileIcon(ctx, profileBtnX + 12, profileBtnY + profileBtnH / 2,
            PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha));
        PurnaGuiRenderer.drawTrimmedText(ctx, tr, profiles.getActiveProfile(), profileBtnX + 22,
            profileBtnY + (profileBtnH - tr.fontHeight) / 2, profileBtnW - 36,
            PurnaTheme.withAlpha(theme.getPrimaryText(), alpha));
        ctx.drawText(tr, profileMenuOpen ? "^" : "v", profileBtnX + profileBtnW - 11,
            profileBtnY + (profileBtnH - tr.fontHeight) / 2,
            PurnaTheme.withAlpha(theme.getSecondaryText(), alpha), false);

        // 1-tap "Photos" gallery picker button beside Profile selector
        photosBtnW = tr.getWidth("Photos") + 16;
        photosBtnH = ctrlH;
        photosBtnX = profileBtnX + profileBtnW + 6;
        photosBtnY = ctrlY;
        boolean photosHover = PurnaGuiRenderer.isHovered(mouseX, mouseY, photosBtnX, photosBtnY, photosBtnW, photosBtnH);
        PurnaGuiRenderer.drawRoundedRect(ctx, photosBtnX, photosBtnY, photosBtnW, photosBtnH, 6,
            PurnaTheme.withAlpha(photosHover ? theme.getPrimaryAccent() : theme.getSelectedCategory(), alpha * 0.85f));
        PurnaGuiRenderer.drawRoundedBorder(ctx, photosBtnX, photosBtnY, photosBtnW, photosBtnH, 6,
            PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha * 0.75f));
        ctx.drawText(tr, "Photos", photosBtnX + 8, photosBtnY + (photosBtnH - tr.fontHeight) / 2,
            PurnaTheme.withAlpha(0xFFFFFFFF, alpha), false);

        if (!statusFlash.isEmpty() && System.currentTimeMillis() < statusFlashUntil && !searchActive) {
            int sx = photosBtnX + photosBtnW + 8;
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, statusFlash, sx,
                profileBtnY + (profileBtnH - tr.fontHeight) / 2, 74,
                PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha));
        }

        // Search button / expanded field left of Close button
        int rightEdge = closeBtnX - 6;
        searchBtnW = ctrlH;
        searchBtnH = ctrlH;
        searchBtnX = rightEdge - searchBtnW;
        searchBtnY = ctrlY;

        if (searchActive || !searchQuery.isEmpty()) {
            int maxSearchW = Math.max(76, rightEdge - (photosBtnX + photosBtnW + 6));
            searchBoxW = Math.min(176, maxSearchW);
            searchBoxH = ctrlH;
            searchBoxX = rightEdge - searchBoxW;
            searchBoxY = ctrlY;

            PurnaGuiRenderer.drawRoundedRect(ctx, searchBoxX, searchBoxY, searchBoxW, searchBoxH, 6,
                PurnaTheme.withAlpha(theme.getCardBackground(), alpha * 0.84f));
            PurnaGuiRenderer.drawRoundedBorder(ctx, searchBoxX, searchBoxY, searchBoxW, searchBoxH, 6,
                PurnaTheme.withAlpha(searchActive ? theme.getPrimaryAccent() : theme.getBorderColor(), alpha));

            PurnaGuiRenderer.drawSearchIcon(ctx, searchBoxX + 11, searchBoxY + searchBoxH / 2,
                PurnaTheme.withAlpha(theme.getSecondaryText(), alpha));

            String display = searchQuery.isEmpty() ? "Search..." : searchQuery;
            boolean blink = searchActive && ((System.currentTimeMillis() / 500) % 2 == 0);
            if (!searchQuery.isEmpty() && blink) display = searchQuery + "|";
            int txtColor = searchQuery.isEmpty() ? theme.getDisabledText() : theme.getPrimaryText();
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, display, searchBoxX + 22,
                searchBoxY + (searchBoxH - tr.fontHeight) / 2, searchBoxW - 40,
                PurnaTheme.withAlpha(txtColor, alpha));

            clearSearchW = 18;
            clearSearchH = 18;
            clearSearchX = searchBoxX + searchBoxW - 20;
            clearSearchY = searchBoxY + (searchBoxH - 18) / 2;
            boolean clearHover = PurnaGuiRenderer.isHovered(mouseX, mouseY, clearSearchX, clearSearchY, clearSearchW, clearSearchH);
            ctx.drawText(tr, "x", clearSearchX + 6, clearSearchY + 5,
                PurnaTheme.withAlpha(clearHover ? theme.getPrimaryText() : theme.getSecondaryText(), alpha), false);
        } else {
            boolean sHover = PurnaGuiRenderer.isHovered(mouseX, mouseY, searchBtnX, searchBtnY, searchBtnW, searchBtnH);
            PurnaGuiRenderer.drawRoundedRect(ctx, searchBtnX, searchBtnY, searchBtnW, searchBtnH, 6,
                PurnaTheme.withAlpha(sHover ? theme.getCardHover() : theme.getCardBackground(), alpha * 0.80f));
            PurnaGuiRenderer.drawRoundedBorder(ctx, searchBtnX, searchBtnY, searchBtnW, searchBtnH, 6,
                PurnaTheme.withAlpha(theme.getBorderColor(), alpha));
            PurnaGuiRenderer.drawSearchIcon(ctx, searchBtnX + searchBtnW / 2, searchBtnY + searchBtnH / 2,
                PurnaTheme.withAlpha(sHover ? theme.getPrimaryText() : theme.getSecondaryText(), alpha));
        }
    }

    public void renderDropdownOverlay(DrawContext ctx, TextRenderer tr, int mouseX, int mouseY,
                                      float alpha, PurnaTheme theme, PurnaProfileManager profiles) {
        if (!profileMenuOpen) return;

        boolean mobile = MobilePlatform.isMobileMode();
        int rowStep = mobile ? 26 : 22;
        int rowH = mobile ? 24 : 20;
        List<String> list = profiles.listProfiles();
        menuW = 196;
        int listRowsH = list.size() * rowStep;
        int inputExtraH = (namingNewProfile || renamingProfile) ? 28 : 0;
        menuH = 34 + listRowsH + inputExtraH + 8;
        menuX = profileBtnX;
        menuY = profileBtnY + profileBtnH + 5;

        PurnaGuiRenderer.drawDropShadow(ctx, menuX, menuY, menuW, menuH, 8, alpha);
        PurnaGuiRenderer.drawRoundedRect(ctx, menuX, menuY, menuW, menuH, 8,
            PurnaTheme.withAlpha(theme.getSecondaryBackground(), alpha * 0.94f));
        PurnaGuiRenderer.drawRoundedBorder(ctx, menuX, menuY, menuW, menuH, 8,
            PurnaTheme.withAlpha(theme.getBorderColor(), alpha));

        int btnY = menuY + 6;
        int btnW = (menuW - 20) / 3;
        drawMiniBtn(ctx, tr, "Save", menuX + 6, btnY, btnW, 20, mouseX, mouseY, alpha, theme, false);
        drawMiniBtn(ctx, tr, "New", menuX + 10 + btnW, btnY, btnW, 20, mouseX, mouseY, alpha, theme, namingNewProfile);
        drawMiniBtn(ctx, tr, "Rename", menuX + 14 + btnW * 2, btnY, btnW, 20, mouseX, mouseY, alpha, theme, renamingProfile);

        int rowY = menuY + 32;
        if (namingNewProfile || renamingProfile) {
            confirmBtnW = 28;
            confirmBtnH = 22;
            confirmBtnX = menuX + menuW - 6 - confirmBtnW;
            confirmBtnY = rowY;
            int inputW = menuW - 16 - confirmBtnW;

            PurnaGuiRenderer.drawRoundedRect(ctx, menuX + 6, rowY, inputW, 22, 5,
                PurnaTheme.withAlpha(theme.getMainBackground(), alpha));
            PurnaGuiRenderer.drawRoundedBorder(ctx, menuX + 6, rowY, inputW, 22, 5,
                PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha));
            String placeholder = namingNewProfile ? "Name..." : "Rename...";
            String txt = profileInput.isEmpty() ? placeholder : profileInput + (((System.currentTimeMillis() / 500) % 2 == 0) ? "|" : "");
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, txt, menuX + 11, rowY + 7, inputW - 10,
                PurnaTheme.withAlpha(profileInput.isEmpty() ? theme.getDisabledText() : theme.getPrimaryText(), alpha));

            drawMiniBtn(ctx, tr, "OK", confirmBtnX, confirmBtnY, confirmBtnW, confirmBtnH, mouseX, mouseY, alpha, theme, true);
            rowY += 28;
        }

        for (String prof : list) {
            boolean active = prof.equalsIgnoreCase(profiles.getActiveProfile());
            boolean hovered = PurnaGuiRenderer.isHovered(mouseX, mouseY, menuX + 6, rowY, menuW - 12, rowH);
            int bg = active ? theme.getSelectedCategory() : (hovered ? theme.getCardHover() : theme.getCardBackground());
            PurnaGuiRenderer.drawRoundedRect(ctx, menuX + 6, rowY, menuW - 12, rowH, 5,
                PurnaTheme.withAlpha(bg, alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, prof, menuX + 12, rowY + (rowH - tr.fontHeight) / 2, menuW - 58,
                PurnaTheme.withAlpha(active ? theme.getPrimaryText() : theme.getSecondaryText(), alpha));

            if (!PurnaProfileManager.DEFAULT_PROFILE.equalsIgnoreCase(prof)) {
                boolean confirming = prof.equalsIgnoreCase(pendingDeleteProfile);
                String delLabel = confirming ? "Sure?" : "Del";
                int delW = confirming ? 36 : 26;
                int delX = menuX + menuW - 10 - delW;
                boolean delHover = PurnaGuiRenderer.isHovered(mouseX, mouseY, delX, rowY + 2, delW, rowH - 4);
                int delBg = confirming ? 0xFFB83B5E : (delHover ? theme.getBorderColor() : theme.getSecondaryBackground());
                PurnaGuiRenderer.drawRoundedRect(ctx, delX, rowY + 2, delW, rowH - 4, 4,
                    PurnaTheme.withAlpha(delBg, alpha));
                PurnaGuiRenderer.drawTrimmedText(ctx, tr, delLabel, delX + 4, rowY + (rowH - tr.fontHeight) / 2, delW - 4,
                    PurnaTheme.withAlpha(theme.getPrimaryText(), alpha));
            }
            rowY += rowStep;
        }
    }

    private void drawMiniBtn(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int h,
                             int mouseX, int mouseY, float alpha, PurnaTheme theme, boolean highlighted) {
        boolean hov = PurnaGuiRenderer.isHovered(mouseX, mouseY, x, y, w, h);
        int bg = highlighted ? theme.getPrimaryAccent() : (hov ? theme.getCardHover() : theme.getCardBackground());
        PurnaGuiRenderer.drawRoundedRect(ctx, x, y, w, h, 5, PurnaTheme.withAlpha(bg, alpha));
        int tw = tr.getWidth(label);
        ctx.drawText(tr, label, x + (w - tw) / 2, y + (h - tr.fontHeight) / 2,
            PurnaTheme.withAlpha(theme.getPrimaryText(), alpha), false);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button, PurnaProfileManager profiles,
                                Runnable onCloseGui, Runnable onOpenPhotos) {
        if (button != 0) return false;

        if (PurnaGuiRenderer.isHovered(mouseX, mouseY, closeBtnX, closeBtnY, closeBtnW, closeBtnH)) {
            if (onCloseGui != null) onCloseGui.run();
            return true;
        }

        if (profileMenuOpen) {
            if (PurnaGuiRenderer.isHovered(mouseX, mouseY, menuX, menuY, menuW, menuH)) {
                int btnY = menuY + 6;
                int btnW = (menuW - 20) / 3;
                if (PurnaGuiRenderer.isHovered(mouseX, mouseY, menuX + 6, btnY, btnW, 20)) {
                    boolean ok = profiles.saveCurrentProfile();
                    flash(ok ? "Saved" : "Save failed");
                    pendingDeleteProfile = null;
                    return true;
                }
                if (PurnaGuiRenderer.isHovered(mouseX, mouseY, menuX + 10 + btnW, btnY, btnW, 20)) {
                    namingNewProfile = !namingNewProfile;
                    renamingProfile = false;
                    profileInput = "";
                    searchActive = false;
                    pendingDeleteProfile = null;
                    return true;
                }
                if (PurnaGuiRenderer.isHovered(mouseX, mouseY, menuX + 14 + btnW * 2, btnY, btnW, 20)) {
                    if (PurnaProfileManager.DEFAULT_PROFILE.equalsIgnoreCase(profiles.getActiveProfile())) {
                        flash("Cannot rename Default");
                    } else {
                        renamingProfile = !renamingProfile;
                        namingNewProfile = false;
                        profileInput = profiles.getActiveProfile();
                        searchActive = false;
                    }
                    pendingDeleteProfile = null;
                    return true;
                }

                if ((namingNewProfile || renamingProfile)
                    && PurnaGuiRenderer.isHovered(mouseX, mouseY, confirmBtnX, confirmBtnY, confirmBtnW, confirmBtnH)) {
                    commitProfileInput(profiles);
                    return true;
                }

                boolean mobile = MobilePlatform.isMobileMode();
                int rowStep = mobile ? 26 : 22;
                int rowH = mobile ? 24 : 20;
                int rowY = menuY + 32 + ((namingNewProfile || renamingProfile) ? 28 : 0);
                for (String prof : profiles.listProfiles()) {
                    if (PurnaGuiRenderer.isHovered(mouseX, mouseY, menuX + 6, rowY, menuW - 12, rowH)) {
                        if (!PurnaProfileManager.DEFAULT_PROFILE.equalsIgnoreCase(prof)) {
                            boolean confirming = prof.equalsIgnoreCase(pendingDeleteProfile);
                            int delW = confirming ? 36 : 26;
                            int delX = menuX + menuW - 10 - delW;
                            if (PurnaGuiRenderer.isHovered(mouseX, mouseY, delX, rowY + 2, delW, rowH - 4)) {
                                if (confirming) {
                                    profiles.deleteProfile(prof);
                                    pendingDeleteProfile = null;
                                    flash("Deleted");
                                } else {
                                    pendingDeleteProfile = prof;
                                }
                                return true;
                            }
                        }
                        profiles.loadProfile(prof);
                        flash("Loaded " + prof);
                        closePopups();
                        return true;
                    }
                    rowY += rowStep;
                }
                return true;
            } else if (!PurnaGuiRenderer.isHovered(mouseX, mouseY, profileBtnX, profileBtnY, profileBtnW, profileBtnH)) {
                closePopups();
            }
        }

        if (PurnaGuiRenderer.isHovered(mouseX, mouseY, photosBtnX, photosBtnY, photosBtnW, photosBtnH)) {
            closePopups();
            if (onOpenPhotos != null) onOpenPhotos.run();
            return true;
        }

        if (PurnaGuiRenderer.isHovered(mouseX, mouseY, profileBtnX, profileBtnY, profileBtnW, profileBtnH)) {
            profileMenuOpen = !profileMenuOpen;
            if (!profileMenuOpen) closePopups();
            else searchActive = false;
            return true;
        }

        if (searchActive || !searchQuery.isEmpty()) {
            if (PurnaGuiRenderer.isHovered(mouseX, mouseY, clearSearchX, clearSearchY, clearSearchW, clearSearchH)) {
                clearSearch();
                return true;
            }
            if (PurnaGuiRenderer.isHovered(mouseX, mouseY, searchBoxX, searchBoxY, searchBoxW, searchBoxH)) {
                searchActive = true;
                closePopups();
                return true;
            } else {
                searchActive = false;
            }
        } else if (PurnaGuiRenderer.isHovered(mouseX, mouseY, searchBtnX, searchBtnY, searchBtnW, searchBtnH)) {
            searchActive = true;
            closePopups();
            return true;
        }

        return false;
    }

    private void commitProfileInput(PurnaProfileManager profiles) {
        String clean = PurnaProfileManager.sanitizeName(profileInput);
        if (!clean.isEmpty()) {
            if (namingNewProfile) {
                boolean ok = profiles.createProfile(clean);
                flash(ok ? "Created " + clean : "Exists/Invalid");
            } else {
                boolean ok = profiles.renameProfile(profiles.getActiveProfile(), clean);
                flash(ok ? "Renamed" : "Rename failed");
            }
        }
        namingNewProfile = false;
        renamingProfile = false;
        profileInput = "";
    }

    public boolean keyPressed(int keyCode, PurnaProfileManager profiles) {
        if (namingNewProfile || renamingProfile) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { namingNewProfile = false; renamingProfile = false; profileInput = ""; return true; }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !profileInput.isEmpty()) { profileInput = profileInput.substring(0, profileInput.length() - 1); return true; }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) { commitProfileInput(profiles); return true; }
            return true;
        }
        if (searchActive) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { clearSearch(); return true; }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !searchQuery.isEmpty()) { searchQuery = searchQuery.substring(0, searchQuery.length() - 1); return true; }
            return true;
        }
        return false;
    }

    public boolean charTyped(char chr) {
        if (Character.isISOControl(chr)) return false;
        if (namingNewProfile || renamingProfile) { if (profileInput.length() < 20) profileInput += chr; return true; }
        if (searchActive) { if (searchQuery.length() < 32) searchQuery += chr; return true; }
        return false;
    }

    private void flash(String msg) {
        this.statusFlash = msg;
        this.statusFlashUntil = System.currentTimeMillis() + 2000L;
    }
}
