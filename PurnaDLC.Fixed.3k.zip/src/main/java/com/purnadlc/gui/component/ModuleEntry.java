package com.purnadlc.gui.component;

import com.purnadlc.animation.PurnaAnimationManager;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.module.Module;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class ModuleEntry {
    private ModuleEntry() {}

    public static final int TOGGLE_W = 28;
    public static final int TOGGLE_H = 14;
    public static final int GEAR_BOX = 18;

    public static void render(DrawContext ctx, TextRenderer tr, Module module,
                              int x, int y, int w, int h,
                              int mouseX, int mouseY, boolean allowHover,
                              float alpha, PurnaTheme theme, PurnaAnimationManager anim,
                              String subtitle) {
        boolean mobile = MobilePlatform.isMobileMode();
        int toggleW = mobile ? 32 : TOGGLE_W;
        int toggleH = mobile ? 16 : TOGGLE_H;
        int gearBox = mobile ? 24 : GEAR_BOX;

        boolean cardHover = allowHover && PurnaGuiRenderer.isHovered(mouseX, mouseY, x, y, w, h);
        float hoverAnim = anim.updateHover("mod_hov_" + module.getName(), cardHover);
        float toggleAnim = anim.updateToggle("mod_tog_" + module.getName(), module.isEnabled());

        int bg = PurnaTheme.lerpColor(theme.getCardBackground(), theme.getCardHover(), hoverAnim);
        PurnaGuiRenderer.drawRoundedRect(ctx, x, y, w, h, PurnaTheme.CARD_RADIUS, PurnaTheme.withAlpha(bg, alpha * 0.72f));

        int border = PurnaTheme.lerpColor(theme.getBorderColor(), theme.getPrimaryAccent(), toggleAnim * 0.25f);
        PurnaGuiRenderer.drawRoundedBorder(ctx, x, y, w, h, PurnaTheme.CARD_RADIUS, PurnaTheme.withAlpha(border, alpha * 0.55f));

        int toggleX = x + w - PurnaTheme.CARD_PADDING_X - toggleW;
        int toggleY = y + (h - toggleH) / 2;

        int gearX = toggleX - (mobile ? 8 : 6) - gearBox;
        int gearY = y + (h - gearBox) / 2;
        boolean gearHover = allowHover && PurnaGuiRenderer.isHovered(mouseX, mouseY, gearX, gearY, gearBox, gearBox);

        int textX = x + PurnaTheme.CARD_PADDING_X;
        int maxTextW = Math.max(24, gearX - textX - 6);
        int textColor = PurnaTheme.lerpColor(theme.getPrimaryText(), 0xFFFFFFFF, toggleAnim * 0.35f);

        if (subtitle != null && !subtitle.isEmpty()) {
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, module.getName(), textX, y + 6, maxTextW,
                PurnaTheme.withAlpha(textColor, alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, subtitle, textX, y + 18, maxTextW,
                PurnaTheme.withAlpha(theme.getDisabledText(), alpha));
        } else {
            int textY = y + (h - tr.fontHeight) / 2;
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, module.getName(), textX, textY, maxTextW,
                PurnaTheme.withAlpha(textColor, alpha));
        }

        if (mobile && module.hasConfigurableSettings()) {
            PurnaGuiRenderer.drawRoundedRect(ctx, gearX, gearY, gearBox, gearBox, 5,
                PurnaTheme.withAlpha(gearHover ? theme.getSelectedCategory() : theme.getSecondaryBackground(), alpha * 0.85f));
        }
        int gearColor = module.hasConfigurableSettings()
            ? (gearHover ? theme.getPrimaryAccent() : theme.getSecondaryText())
            : theme.getDisabledText();
        PurnaGuiRenderer.drawGearIcon(ctx, gearX + gearBox / 2, gearY + gearBox / 2,
            PurnaTheme.withAlpha(gearColor, alpha));

        PurnaGuiRenderer.drawToggle(ctx, toggleX, toggleY, toggleW, toggleH, toggleAnim, theme, alpha);
    }

    public enum ClickAction {
        NONE,
        TOGGLE,
        SETTINGS,
        JUMP
    }

    public static ClickAction hitTest(double mouseX, double mouseY, int button,
                                      int x, int y, int w, int h, boolean searchMode) {
        if (!PurnaGuiRenderer.isHovered(mouseX, mouseY, x, y, w, h)) {
            return ClickAction.NONE;
        }
        boolean mobile = MobilePlatform.isMobileMode();
        int toggleW = mobile ? 32 : TOGGLE_W;
        int gearBox = mobile ? 24 : GEAR_BOX;
        int toggleX = x + w - PurnaTheme.CARD_PADDING_X - toggleW;
        int gearX = toggleX - (mobile ? 8 : 6) - gearBox;

        if (button == 1) {
            return ClickAction.SETTINGS;
        }
        if (button != 0) {
            return ClickAction.NONE;
        }

        if (mouseX >= toggleX - 4) {
            return ClickAction.TOGGLE;
        }
        if (mouseX >= gearX - 4 && mouseX < toggleX - 4) {
            return ClickAction.SETTINGS;
        }
        return searchMode ? ClickAction.JUMP : ClickAction.TOGGLE;
    }
}
