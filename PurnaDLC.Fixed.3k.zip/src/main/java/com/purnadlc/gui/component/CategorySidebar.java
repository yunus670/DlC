package com.purnadlc.gui.component;

import com.purnadlc.PurnaDLC;
import com.purnadlc.animation.PurnaAnimationManager;
import com.purnadlc.gui.ClickGuiVideoBackground;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.module.Category;
import com.purnadlc.module.impl.misc.NameProtectModule;
import com.purnadlc.platform.MobilePlatform;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Consumer;

public final class CategorySidebar {
    private record Rect(int x, int y, int w, int h) {}

    private final Map<Category, Rect> itemBounds = new EnumMap<>(Category.class);
    private Category selectedCategory = Category.VISUALS;

    public Category getSelectedCategory() {
        return selectedCategory;
    }

    public void setSelectedCategory(Category category) {
        if (category != null) {
            this.selectedCategory = category;
        }
    }

    public void render(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                       int mouseX, int mouseY, float alpha, PurnaTheme theme, PurnaAnimationManager anim) {
        itemBounds.clear();

        // Sidebar slightly deeper surface & right divider
        int sidebarBg = PurnaTheme.withAlpha(theme.getMainBackground(), alpha * 0.56f);
        PurnaGuiRenderer.drawRoundedRect(ctx, x, y, w, h, PurnaTheme.WINDOW_RADIUS, sidebarBg);
        ctx.fill(x + w - 1, y + 6, x + w, y + h - 6, PurnaTheme.withAlpha(theme.getBorderColor(), alpha * 0.85f));

        // Brand header: geometric PurnaDLC logo + text
        int logoX = x + 12;
        int logoY = y + 12;
        if (!ClickGuiVideoBackground.draw4kLogo(ctx, logoX, logoY, 22, alpha)) {
            PurnaGuiRenderer.drawPurnaLogo(ctx, logoX, logoY, 20, theme, alpha);
        }
        PurnaGuiRenderer.drawTrimmedText(ctx, tr, "PURNADLC", logoX + 25, logoY + 2, w - 42,
            PurnaTheme.withAlpha(theme.getPrimaryText(), alpha));
        PurnaGuiRenderer.drawTrimmedText(ctx, tr, "Client", logoX + 25, logoY + 12, w - 42,
            PurnaTheme.withAlpha(theme.getDisabledText(), alpha));

        int cursorY = y + 48;

        // MAIN section
        cursorY = renderGroup(ctx, tr, Category.SidebarGroup.MAIN, x, cursorY, w, mouseX, mouseY, alpha, theme, anim);
        cursorY += 8;

        // OTHER section
        renderGroup(ctx, tr, Category.SidebarGroup.OTHER, x, cursorY, w, mouseX, mouseY, alpha, theme, anim);

        // Bottom profile badge (matches screenshot lower-left user card)
        int footerH = 34;
        int footerY = y + h - footerH - 8;
        int footerX = x + 8;
        int footerW = w - 16;
        if (footerY > y + 250) {
            PurnaGuiRenderer.drawRoundedRect(ctx, footerX, footerY, footerW, footerH, 7,
                PurnaTheme.withAlpha(theme.getSecondaryBackground(), alpha));
            PurnaGuiRenderer.drawRoundedBorder(ctx, footerX, footerY, footerW, footerH, 7,
                PurnaTheme.withAlpha(theme.getBorderColor(), alpha * 0.7f));

            // Geometric user avatar badge
            int avX = footerX + 6;
            int avY = footerY + 7;
            PurnaGuiRenderer.drawRoundedRect(ctx, avX, avY, 20, 20, 6,
                PurnaTheme.withAlpha(theme.getSelectedCategory(), alpha));
            if (!ClickGuiVideoBackground.draw4kLogo(ctx, avX + 3, avY + 3, 14, alpha)) {
                PurnaGuiRenderer.drawPurnaLogo(ctx, avX + 4, avY + 4, 12, theme, alpha);
            }

            String username = resolveUsername();
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, username, avX + 25, footerY + 7, footerW - 35,
                PurnaTheme.withAlpha(theme.getPrimaryText(), alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, MobilePlatform.isMobileMode() ? MobilePlatform.getLauncherLabel() : "1.21.11", avX + 25, footerY + 18, footerW - 35,
                PurnaTheme.withAlpha(theme.getDisabledText(), alpha));
        }
    }

    private int renderGroup(DrawContext ctx, TextRenderer tr, Category.SidebarGroup group,
                            int x, int startY, int w, int mouseX, int mouseY,
                            float alpha, PurnaTheme theme, PurnaAnimationManager anim) {
        int cy = startY;
        ctx.drawText(tr, group.getHeader(), x + 12, cy,
            PurnaTheme.withAlpha(theme.getDisabledText(), alpha), false);
        cy += 13;

        int itemX = x + 8;
        int itemW = w - 16;
        int itemH = MobilePlatform.isMobileMode() ? 28 : 24;

        for (Category cat : Category.values()) {
            if (cat.getGroup() != group) continue;

            boolean selected = (cat == selectedCategory);
            boolean hovered = PurnaGuiRenderer.isHovered(mouseX, mouseY, itemX, cy, itemW, itemH);

            float selAnim = anim.updateSidebar("cat_sel_" + cat.name(), selected);
            float hovAnim = anim.updateHover("cat_hov_" + cat.name(), hovered && !selected);

            if (selAnim > 0.01f) {
                int selColor = PurnaTheme.withAlpha(theme.getSelectedCategory(), alpha * selAnim);
                PurnaGuiRenderer.drawRoundedRect(ctx, itemX, cy, itemW, itemH, 6, selColor);
                // Subtle purple left indicator bar
                int barColor = PurnaTheme.withAlpha(theme.getPrimaryAccent(), alpha * selAnim);
                ctx.fill(itemX + 2, cy + 5, itemX + 4, cy + itemH - 5, barColor);
            } else if (hovAnim > 0.01f) {
                int hovColor = PurnaTheme.withAlpha(theme.getCardHover(), alpha * hovAnim * 0.55f);
                PurnaGuiRenderer.drawRoundedRect(ctx, itemX, cy, itemW, itemH, 6, hovColor);
            }

            int iconColor = PurnaTheme.lerpColor(theme.getSecondaryText(), theme.getPrimaryAccent(), Math.max(selAnim, hovAnim * 0.4f));
            int textColor = PurnaTheme.lerpColor(theme.getSecondaryText(), theme.getPrimaryText(), Math.max(selAnim, hovAnim * 0.5f));

            PurnaGuiRenderer.drawCategoryIcon(ctx, cat.getIconId(), itemX + 8, cy + 8,
                PurnaTheme.withAlpha(iconColor, alpha));
            PurnaGuiRenderer.drawTrimmedText(ctx, tr, cat.getDisplayName(), itemX + 22, cy + 8, itemW - 26,
                PurnaTheme.withAlpha(textColor, alpha));

            itemBounds.put(cat, new Rect(itemX, cy, itemW, itemH));
            cy += itemH + 3;
        }
        return cy;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button, Consumer<Category> onCategoryChanged) {
        if (button != 0) return false;
        for (Map.Entry<Category, Rect> entry : itemBounds.entrySet()) {
            Rect r = entry.getValue();
            if (PurnaGuiRenderer.isHovered(mouseX, mouseY, r.x, r.y, r.w, r.h)) {
                if (this.selectedCategory != entry.getKey()) {
                    this.selectedCategory = entry.getKey();
                    if (onCategoryChanged != null) {
                        onCategoryChanged.accept(this.selectedCategory);
                    }
                }
                return true;
            }
        }
        return false;
    }

    private String resolveUsername() {
        MinecraftClient mc = MinecraftClient.getInstance();
        String real = (mc != null && mc.getSession() != null) ? mc.getSession().getUsername() : "Player";
        PurnaDLC instance = PurnaDLC.getInstance();
        if (instance != null) {
            NameProtectModule np = instance.getModuleManager().getModule(NameProtectModule.class);
            if (np != null) {
                return np.getDisplayUsername(real);
            }
        }
        return real;
    }
}
