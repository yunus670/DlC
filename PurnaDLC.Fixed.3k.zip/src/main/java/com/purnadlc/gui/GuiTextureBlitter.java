package com.purnadlc.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Function;
import java.util.function.Supplier;

public final class GuiTextureBlitter {
    private static boolean initialized = false;
    private static Method drawTexWithColorMethod = null;
    private static Method drawTexBasicMethod = null;
    private static Object guiPipelineOrLayerFactory = null;
    private static boolean drawTakes13Args = false;
    private static boolean drawTakes10Args = false;

    private static Constructor<?> texSupplierCtor = null;
    private static Constructor<?> texDirectCtor = null;
    private static Method setPixelMethod = null;
    private static boolean pixelIsArgb = true;

    private GuiTextureBlitter() {}

    private static void ensureInit() {
        if (initialized) return;
        initialized = true;

        try {
            Class<?> pipelinesClass = Class.forName("net.minecraft.client.gl.RenderPipelines");
            Field f = pipelinesClass.getField("GUI_TEXTURED");
            guiPipelineOrLayerFactory = f.get(null);
        } catch (Throwable ignored) {
        }

        if (guiPipelineOrLayerFactory == null) {
            try {
                Class<?> rlClass = Class.forName("net.minecraft.client.render.RenderLayer");
                Method getGui = rlClass.getMethod("getGuiTextured", Identifier.class);
                guiPipelineOrLayerFactory = (Function<Identifier, Object>) id -> {
                    try {
                        return getGui.invoke(null, id);
                    } catch (Throwable t) {
                        return null;
                    }
                };
            } catch (Throwable ignored) {
            }
        }

        if (guiPipelineOrLayerFactory != null) {
            for (Method m : DrawContext.class.getMethods()) {
                if (!m.getName().equals("drawTexture")) continue;
                Class<?>[] p = m.getParameterTypes();
                if (p.length == 13
                    && p[0].isAssignableFrom(guiPipelineOrLayerFactory.getClass())
                    && p[1] == Identifier.class
                    && p[2] == int.class && p[3] == int.class
                    && p[4] == float.class && p[5] == float.class
                    && p[12] == int.class) {
                    drawTexWithColorMethod = m;
                    drawTakes13Args = true;
                }
                if (p.length == 10
                    && p[0].isAssignableFrom(guiPipelineOrLayerFactory.getClass())
                    && p[1] == Identifier.class
                    && p[2] == int.class && p[3] == int.class
                    && p[4] == float.class && p[5] == float.class
                    && p[8] == int.class && p[9] == int.class) {
                    drawTexBasicMethod = m;
                    drawTakes10Args = true;
                }
            }
        }

        for (Constructor<?> c : NativeImageBackedTexture.class.getConstructors()) {
            Class<?>[] p = c.getParameterTypes();
            if (p.length == 2 && p[0] == Supplier.class && p[1] == NativeImage.class) {
                texSupplierCtor = c;
            } else if (p.length == 1 && p[0] == NativeImage.class) {
                texDirectCtor = c;
            }
        }

        try {
            setPixelMethod = NativeImage.class.getMethod("setColorArgb", int.class, int.class, int.class);
            pixelIsArgb = true;
        } catch (Throwable ignored) {
            try {
                setPixelMethod = NativeImage.class.getMethod("setColor", int.class, int.class, int.class);
                pixelIsArgb = false;
            } catch (Throwable ignored2) {
            }
        }
    }

    public static NativeImageBackedTexture createTexture(String label, NativeImage image) {
        ensureInit();
        if (image == null) return null;
        try {
            if (texSupplierCtor != null) {
                Supplier<String> sup = () -> label;
                return (NativeImageBackedTexture) texSupplierCtor.newInstance(sup, image);
            }
            if (texDirectCtor != null) {
                return (NativeImageBackedTexture) texDirectCtor.newInstance(image);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    public static void setPixelRgba(NativeImage image, int x, int y, int r, int g, int b, int a) {
        ensureInit();
        if (image == null || setPixelMethod == null) return;
        int packed = pixelIsArgb
            ? ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF)
            : ((a & 0xFF) << 24) | ((b & 0xFF) << 16) | ((g & 0xFF) << 8) | (r & 0xFF);
        try {
            setPixelMethod.invoke(image, x, y, packed);
        } catch (Throwable ignored) {
        }
    }

    public static boolean drawFullTexture(DrawContext ctx, Identifier id, int x, int y, int w, int h, int argbColor) {
        ensureInit();
        if (ctx == null || id == null || w <= 0 || h <= 0 || guiPipelineOrLayerFactory == null) return false;
        try {
            if (drawTakes13Args && drawTexWithColorMethod != null) {
                drawTexWithColorMethod.invoke(
                    ctx, guiPipelineOrLayerFactory, id,
                    x, y, 0.0f, 0.0f, w, h, w, h, w, h, argbColor
                );
                return true;
            }
            if (drawTakes10Args && drawTexBasicMethod != null) {
                drawTexBasicMethod.invoke(
                    ctx, guiPipelineOrLayerFactory, id,
                    x, y, 0.0f, 0.0f, w, h, w, h
                );
                return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    public static boolean drawCoverTexture(DrawContext ctx, Identifier id,
                                           int x, int y, int boxW, int boxH,
                                           int srcW, int srcH, int argbColor) {
        ensureInit();
        if (ctx == null || id == null || boxW <= 0 || boxH <= 0 || srcW <= 0 || srcH <= 0) return false;
        double boxAspect = (double) boxW / boxH;
        double srcAspect = (double) srcW / srcH;

        int drawW = boxW, drawH = boxH, drawX = x, drawY = y;
        if (srcAspect > boxAspect) {
            drawH = boxH;
            drawW = (int) Math.ceil(boxH * srcAspect);
            drawX = x - (drawW - boxW) / 2;
        } else {
            drawW = boxW;
            drawH = (int) Math.ceil(boxW / srcAspect);
            drawY = y - (drawH - boxH) / 2;
        }

        boolean scissored = PurnaGuiRenderer.safeEnableScissor(ctx, x, y, x + boxW, y + boxH);
        boolean ok = drawFullTexture(ctx, id, drawX, drawY, drawW, drawH, argbColor);
        if (scissored) ctx.disableScissor();
        return ok;
    }
}
