package com.purnadlc.gui;

public final class ScrollController {
    private float scrollOffset = 0f;
    private float targetOffset = 0f;
    private float flingVelocity = 0f;
    private int contentHeight = 0;
    private int viewportHeight = 1;

    private boolean touchDragging = false;
    private double lastDragY = 0.0;
    private double totalDragDistance = 0.0;

    public void setBounds(int contentHeight, int viewportHeight) {
        this.contentHeight = Math.max(0, contentHeight);
        this.viewportHeight = Math.max(1, viewportHeight);
        clampTargets();
    }

    public void onWheel(double verticalAmount) {
        flingVelocity = 0f;
        targetOffset -= (float) (verticalAmount * 24.0);
        clampTargets();
    }

    public void beginTouchDrag(double y) {
        touchDragging = true;
        lastDragY = y;
        totalDragDistance = 0.0;
        flingVelocity = 0f;
    }

    public boolean updateTouchDrag(double y) {
        if (!touchDragging) return false;
        double delta = y - lastDragY;
        lastDragY = y;
        totalDragDistance += Math.abs(delta);
        if (Math.abs(delta) > 0.25) {
            targetOffset -= (float) delta;
            flingVelocity = (float) (-delta * 18.0);
            clampTargets();
            scrollOffset = targetOffset;
            return true;
        }
        return false;
    }

    public void endTouchDrag() {
        touchDragging = false;
        if (totalDragDistance < 4.0) {
            flingVelocity = 0f;
        }
    }

    public double getTotalDragDistance() {
        return totalDragDistance;
    }

    public void update(float deltaSeconds) {
        float dt = Math.max(0.001f, Math.min(0.08f, deltaSeconds));
        if (!touchDragging && Math.abs(flingVelocity) > 2.0f) {
            targetOffset += flingVelocity * dt;
            flingVelocity *= (float) Math.exp(-7.5f * dt);
        } else if (!touchDragging) {
            flingVelocity = 0f;
        }

        clampTargets();
        float factor = 1f - (float) Math.exp(-16f * dt);
        scrollOffset += (targetOffset - scrollOffset) * factor;
        if (Math.abs(targetOffset - scrollOffset) < 0.25f) {
            scrollOffset = targetOffset;
        }
    }

    public void reset() {
        scrollOffset = 0f;
        targetOffset = 0f;
        flingVelocity = 0f;
        touchDragging = false;
        totalDragDistance = 0.0;
    }

    public int getScrollInt() {
        return Math.round(scrollOffset);
    }

    public int getMaxScroll() {
        return Math.max(0, contentHeight - viewportHeight);
    }

    public boolean canScroll() {
        return getMaxScroll() > 0;
    }

    public float getScrollRatio() {
        int max = getMaxScroll();
        return max <= 0 ? 0f : Math.max(0f, Math.min(1f, scrollOffset / max));
    }

    private void clampTargets() {
        float max = getMaxScroll();
        if (targetOffset < 0f) {
            targetOffset = 0f;
            flingVelocity = 0f;
        }
        if (targetOffset > max) {
            targetOffset = max;
            flingVelocity = 0f;
        }
        if (scrollOffset < 0f) scrollOffset = 0f;
        if (scrollOffset > max) scrollOffset = max;
    }
}
