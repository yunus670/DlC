package com.purnadlc.visual;

import com.purnadlc.PurnaDLC;
import com.purnadlc.combat.aura.AttackAura;
import com.purnadlc.combat.aura.RotationMath;
import com.purnadlc.gui.PurnaGuiRenderer;
import com.purnadlc.module.ModuleManager;
import com.purnadlc.module.impl.visual.*;
import com.purnadlc.theme.PurnaTheme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.*;

public final class PurnaVisualEngine {
    private final WorldProjection proj = new WorldProjection();
    private final Deque<Vec3d> trailPoints = new ArrayDeque<>(96);

    private static final class VisualParticle {
        double x, y, z, vx, vy, vz;
        long bornMs, lifeMs;
        int color;
        String shape;
    }
    private final List<VisualParticle> particles = new ArrayList<>(128);

    private static final class HitMarker {
        double x, y, z;
        long bornMs, lifeMs;
        int color;
    }
    private final List<HitMarker> hitMarkers = new ArrayList<>(32);
    private final Map<Integer, Integer> lastHurtTimes = new HashMap<>(64);

    private final float[] starAzimuth = new float[48];
    private final float[] starElevation = new float[48];

    private boolean wasOnGround = true;
    private long lastWorldHash = 0L;

    public PurnaVisualEngine() {
        Random rng = new Random(19982026L);
        for (int i = 0; i < starAzimuth.length; i++) {
            starAzimuth[i] = rng.nextFloat() * 360.0f;
            starElevation[i] = 8.0f + rng.nextFloat() * 72.0f;
        }
    }

    public void onTick(MinecraftClient mc) {
        PurnaDLC client = PurnaDLC.getInstance();
        if (mc == null || mc.player == null || mc.world == null || client == null) {
            trailPoints.clear();
            particles.clear();
            hitMarkers.clear();
            lastHurtTimes.clear();
            return;
        }

        long worldHash = System.identityHashCode(mc.world);
        if (worldHash != lastWorldHash) {
            trailPoints.clear();
            particles.clear();
            hitMarkers.clear();
            lastHurtTimes.clear();
            lastWorldHash = worldHash;
        }

        ModuleManager mm = client.getModuleManager();
        long now = System.currentTimeMillis();

        AmbienceModule amb = mm.getModule(AmbienceModule.class);
        if (amb != null && amb.isEnabled()) {
            try {
                Object props = mc.world.getLevelProperties();
                if (props != null) {
                    props.getClass().getMethod("setTimeOfDay", long.class).invoke(props, (long) amb.worldTime.getInt());
                }
            } catch (Throwable ignored) {}
        }

        RoolsModule rools = mm.getModule(RoolsModule.class);
        if (rools != null && rools.isEnabled()) {
            Vec3d pos = new Vec3d(mc.player.getX(), mc.player.getY() + 0.15, mc.player.getZ());
            if (trailPoints.isEmpty() || trailPoints.peekLast().distanceTo(pos) > 0.12) {
                trailPoints.addLast(pos);
                int maxPts = Math.max(8, (int) Math.round(rools.length.getValue() * 8.0));
                while (trailPoints.size() > maxPts) trailPoints.removeFirst();
            }
        } else if (!trailPoints.isEmpty()) {
            trailPoints.clear();
        }

        ParticlesModule partMod = mm.getModule(ParticlesModule.class);
        boolean justJumped = wasOnGround && !mc.player.isOnGround() && mc.player.getVelocity().y > 0.1;
        wasOnGround = mc.player.isOnGround();

        if (partMod != null && partMod.isEnabled()) {
            if (justJumped) {
                spawnParticleBurst(mc.player.getX(), mc.player.getY() + 0.2, mc.player.getZ(),
                    Math.min(18, partMod.count.getInt()), partMod.color.getValue(), partMod.shape.getValue(), now);
            } else if (mc.player.isSprinting() && (now % 160L) < 55L) {
                spawnParticleBurst(mc.player.getX(), mc.player.getY() + 0.35, mc.player.getZ(),
                    2, partMod.color.getValue(), partMod.shape.getValue(), now);
            }
        }

        Iterator<VisualParticle> pit = particles.iterator();
        while (pit.hasNext()) {
            VisualParticle p = pit.next();
            if (now - p.bornMs > p.lifeMs) pit.remove();
            else {
                p.x += p.vx; p.y += p.vy; p.z += p.vz;
                p.vy -= 0.008; p.vx *= 0.96; p.vz *= 0.96;
            }
        }

        HitPointModule hitMod = mm.getModule(HitPointModule.class);
        if ((hitMod != null && hitMod.isEnabled()) || (partMod != null && partMod.isEnabled())) {
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof LivingEntity living) || living == mc.player) continue;
                int id = living.getId();
                int prevHurt = lastHurtTimes.getOrDefault(id, 0);
                int curHurt = living.hurtTime;
                if (curHurt > prevHurt && curHurt >= 8) {
                    Vec3d center = living.getBoundingBox().getCenter();
                    if (hitMod != null && hitMod.isEnabled()) {
                        HitMarker hm = new HitMarker();
                        hm.x = center.x; hm.y = center.y; hm.z = center.z;
                        hm.bornMs = now;
                        hm.lifeMs = Math.round(hitMod.duration.getValue() * 1000.0);
                        hm.color = hitMod.color.getValue();
                        hitMarkers.add(hm);
                    }
                    if (partMod != null && partMod.isEnabled()) {
                        spawnParticleBurst(center.x, center.y, center.z,
                            Math.min(24, partMod.count.getInt()), partMod.color.getValue(), partMod.shape.getValue(), now);
                    }
                }
                lastHurtTimes.put(id, curHurt);
            }
        }

        hitMarkers.removeIf(h -> (now - h.bornMs) > h.lifeMs);
    }

    private void spawnParticleBurst(double x, double y, double z, int count, int color, String shape, long now) {
        if (particles.size() > 120) return;
        for (int i = 0; i < count; i++) {
            VisualParticle p = new VisualParticle();
            double angle = (Math.PI * 2.0 * i) / Math.max(1, count) + (now % 100) * 0.03;
            double speed = 0.04 + (i % 4) * 0.02;
            p.x = x; p.y = y; p.z = z;
            p.vx = Math.cos(angle) * speed;
            p.vy = 0.06 + (i % 3) * 0.035;
            p.vz = Math.sin(angle) * speed;
            p.bornMs = now;
            p.lifeMs = 750L + (i % 4) * 180L;
            p.color = color;
            p.shape = shape;
            particles.add(p);
        }
    }

    public void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PurnaDLC client = PurnaDLC.getInstance();
        if (mc == null || client == null || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (!proj.beginFrame(mc)) return;

        ModuleManager mm = client.getModuleManager();
        PurnaTheme theme = client.getTheme();
        TextRenderer tr = mc.textRenderer;
        long now = System.currentTimeMillis();

        ShaderSkyModule sky = mm.getModule(ShaderSkyModule.class);
        if (sky != null && sky.isEnabled()) renderShaderSky(ctx, mc, sky, now);

        AmbienceModule amb = mm.getModule(AmbienceModule.class);
        if (amb != null && amb.isEnabled()) renderAmbienceOverlay(ctx, amb, now);

        boolean thirdPerson = mc.options.getPerspective() != Perspective.FIRST_PERSON;
        RoolsModule rools = mm.getModule(RoolsModule.class);
        if (rools != null && rools.isEnabled()) renderRoolsTrail(ctx, rools);

        ChinaHatModule hat = mm.getModule(ChinaHatModule.class);
        if (hat != null && hat.isEnabled() && thirdPerson) renderChinaHat(ctx, mc.player, hat);

        WingsModule wings = mm.getModule(WingsModule.class);
        if (wings != null && wings.isEnabled() && thirdPerson) renderWings(ctx, mc.player, wings, now);

        CustomModelsModule models = mm.getModule(CustomModelsModule.class);
        if (models != null && models.isEnabled()) renderCustomModels(ctx, mc, models, thirdPerson, now);

        BlockOverlayModule blockMod = mm.getModule(BlockOverlayModule.class);
        if (blockMod != null && blockMod.isEnabled()) renderBlockOverlay(ctx, mc, blockMod);

        PredictionModule predMod = mm.getModule(PredictionModule.class);
        if (predMod != null && predMod.isEnabled()) renderPrediction(ctx, mc, predMod);

        ParticlesModule partMod = mm.getModule(ParticlesModule.class);
        if (partMod != null && partMod.isEnabled()) renderParticles(ctx, now);

        HitPointModule hitMod = mm.getModule(HitPointModule.class);
        if (hitMod != null && hitMod.isEnabled()) renderHitPoints(ctx, now);

        ItemRendererModule itemMod = mm.getModule(ItemRendererModule.class);
        if (itemMod != null && itemMod.isEnabled()) renderDroppedItemLabels(ctx, mc, tr, theme);

        BoxModule boxMod = mm.getModule(BoxModule.class);
        ChamsModule chamsMod = mm.getModule(ChamsModule.class);
        TagsModule tagsMod = mm.getModule(TagsModule.class);
        ArrowsModule arrowsMod = mm.getModule(ArrowsModule.class);
        TargetESPModule targetEsp = mm.getModule(TargetESPModule.class);

        if ((boxMod != null && boxMod.isEnabled())
            || (chamsMod != null && chamsMod.isEnabled())
            || (tagsMod != null && tagsMod.isEnabled())
            || (arrowsMod != null && arrowsMod.isEnabled())) {
            renderEntityVisuals(ctx, mc, tr, theme, boxMod, chamsMod, tagsMod, arrowsMod);
        }

        if (targetEsp != null && targetEsp.isEnabled()) renderTargetEsp(ctx, mc, mm, targetEsp, now);

        ShaderHandsModule hands = mm.getModule(ShaderHandsModule.class);
        if (hands != null && hands.isEnabled() && !thirdPerson) renderShaderHandsAccent(ctx, hands, now);
    }

    private void renderDroppedItemLabels(DrawContext ctx, MinecraftClient mc, TextRenderer tr, PurnaTheme theme) {
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity itemEnt) || !itemEnt.isAlive()) continue;
            double dist = mc.player.getEyePos().distanceTo(itemEnt.getBoundingBox().getCenter());
            if (dist > 24.0 || !isEntityVisible(mc, itemEnt)) continue;
            WorldProjection.ScreenPoint sp = proj.project(itemEnt.getX(), itemEnt.getBoundingBox().maxY + 0.25, itemEnt.getZ());
            if (!sp.visible()) continue;
            ItemStack st = itemEnt.getStack();
            if (st.isEmpty()) continue;
            String label = st.getName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : "");
            int tw = tr.getWidth(label);
            int px = Math.round(sp.x()) - tw / 2 - 4;
            int py = Math.round(sp.y()) - 12;
            PurnaGuiRenderer.drawRoundedRect(ctx, px, py, tw + 8, 12, 3, PurnaTheme.withAlpha(theme.getMainBackground(), 0.78f));
            ctx.drawText(tr, label, px + 4, py + 2, theme.getPrimaryText(), false);
        }
    }

    private void renderShaderSky(DrawContext ctx, MinecraftClient mc, ShaderSkyModule sky, long now) {
        int w = proj.getScreenW(), h = proj.getScreenH();
        int horizonY = Math.round(h * 0.50f + (mc.player.getPitch() / 90.0f) * h * 0.55f);
        if (horizonY <= 0) return;

        int skyH = Math.min(h, horizonY);
        int baseTint = sky.tint.getValue();
        int topColor, midColor;
        switch (sky.preset.getValue()) {
            case "Nebula" -> { topColor = 0xFF281242; midColor = baseTint; }
            case "Midnight" -> { topColor = 0xFF0A0D1F; midColor = 0xFF2A2D66; }
            case "Dusk" -> { topColor = 0xFF2E1838; midColor = 0xFFB85A82; }
            default -> { topColor = 0xFF16132E; midColor = PurnaTheme.lerpColor(baseTint, 0xFF47C992, 0.35f); }
        }

        int bands = 14;
        int bandH = Math.max(1, skyH / bands);
        for (int i = 0; i < bands; i++) {
            float t = (float) i / bands;
            int col = PurnaTheme.lerpColor(topColor, midColor, t);
            int alpha = Math.round((0.30f - 0.24f * t) * 255f);
            ctx.fill(0, i * bandH, w, Math.min(skyH, (i + 1) * bandH + 1), PurnaTheme.overrideAlpha(col, alpha));
        }

        if ("Aurora".equalsIgnoreCase(sky.preset.getValue()) || "Nebula".equalsIgnoreCase(sky.preset.getValue())) {
            double phase = now * 0.0012;
            int step = Math.max(12, w / 36);
            for (int x = 0; x < w; x += step) {
                double wave = Math.sin(x * 0.015 + phase) * 14.0 + Math.cos(x * 0.009 - phase * 0.7) * 9.0;
                int ry = Math.round(skyH * 0.28f + (float) wave);
                if (ry > 4 && ry < skyH - 12) {
                    ctx.fill(x, ry, x + step, ry + 8, PurnaTheme.overrideAlpha(midColor, 34));
                    ctx.fill(x, ry + 2, x + step, ry + 5, PurnaTheme.overrideAlpha(baseTint, 46));
                }
            }
        }

        if (sky.stars.isEnabled()) {
            float yaw = RotationMath.normalizeYaw(mc.player.getYaw());
            for (int i = 0; i < starAzimuth.length; i++) {
                float relYaw = RotationMath.yawDifference(yaw, starAzimuth[i] - 180.0f);
                if (Math.abs(relYaw) > 65.0f) continue;
                int sx = Math.round(w * 0.5f + (relYaw / 65.0f) * w * 0.5f);
                int sy = Math.round(horizonY - (starElevation[i] / 85.0f) * h * 0.72f);
                if (sy > 2 && sy < skyH - 6) {
                    int twinkle = 110 + (int) (Math.sin(now * 0.004 + i * 1.7) * 90);
                    ctx.fill(sx, sy, sx + 2, sy + 2, PurnaTheme.overrideAlpha(0xFFFFFF, Math.max(40, Math.min(220, twinkle))));
                }
            }
        }
    }

    private void renderAmbienceOverlay(DrawContext ctx, AmbienceModule amb, long now) {
        int w = proj.getScreenW(), h = proj.getScreenH();
        ctx.fill(0, 0, w, h, PurnaTheme.overrideAlpha(amb.fogColor.getValue(), 22));
        String weather = amb.weather.getValue();
        if ("Rain".equalsIgnoreCase(weather) || "Thunder".equalsIgnoreCase(weather)) {
            int drops = "Thunder".equalsIgnoreCase(weather) ? 40 : 24;
            int col = PurnaTheme.overrideAlpha(0x9EC5FF, 55);
            for (int i = 0; i < drops; i++) {
                int rx = (int) ((i * 97 + (now / 4) * (1 + (i % 2))) % Math.max(1, w));
                int ry = (int) ((i * 53 + (now / 2) * (2 + (i % 3))) % Math.max(1, h));
                ctx.fill(rx, ry, rx + 1, ry + 9, col);
            }
        }
    }

    private void renderChinaHat(DrawContext ctx, Entity player, ChinaHatModule hat) {
        double r = hat.radius.getValue(), height = hat.height.getValue();
        WorldProjection.ScreenPoint apex = proj.project(player.getX(), player.getBoundingBox().maxY + 0.08 + height, player.getZ());
        if (!apex.visible()) return;
        int segments = 24;
        int topCol = PurnaTheme.overrideAlpha(hat.topColor.getValue(), 210);
        int rimCol = PurnaTheme.overrideAlpha(hat.rimColor.getValue(), 225);
        WorldProjection.ScreenPoint prev = null, first = null;
        for (int i = 0; i <= segments; i++) {
            double ang = (Math.PI * 2.0 * i) / segments;
            WorldProjection.ScreenPoint pt = proj.project(
                player.getX() + Math.cos(ang) * r,
                player.getBoundingBox().maxY + 0.08,
                player.getZ() + Math.sin(ang) * r
            );
            if (!pt.visible()) continue;
            if (first == null) first = pt;
            drawLine(ctx, Math.round(apex.x()), Math.round(apex.y()), Math.round(pt.x()), Math.round(pt.y()), topCol);
            if (prev != null) drawLine(ctx, Math.round(prev.x()), Math.round(prev.y()), Math.round(pt.x()), Math.round(pt.y()), rimCol);
            prev = pt;
        }
        if (prev != null && first != null) {
            drawLine(ctx, Math.round(prev.x()), Math.round(prev.y()), Math.round(first.x()), Math.round(first.y()), rimCol);
        }
    }

    private void renderWings(DrawContext ctx, Entity player, WingsModule wings, long now) {
        double scale = wings.scale.getValue();
        double yawRad = Math.toRadians(player.getYaw());
        double backX = Math.sin(yawRad), backZ = -Math.cos(yawRad);
        double rightX = Math.cos(yawRad), rightZ = Math.sin(yawRad);
        double baseY = player.getY() + 1.22;
        double ox = player.getX() + backX * 0.24, oz = player.getZ() + backZ * 0.24;
        double flap = Math.sin(now * 0.0065) * 0.22;
        int mainCol = PurnaTheme.overrideAlpha(wings.color.getValue(), 220);
        int accentCol = PurnaTheme.overrideAlpha(PurnaTheme.DEFAULT_PRIMARY_PURPLE, 185);
        int featherCount = "Dragon".equalsIgnoreCase(wings.style.getValue()) ? 5 : 7;

        for (int side : new int[]{-1, 1}) {
            WorldProjection.ScreenPoint prevTip = null;
            WorldProjection.ScreenPoint root = proj.project(ox, baseY, oz);
            if (!root.visible()) continue;
            for (int f = 0; f < featherCount; f++) {
                double t = (double) f / Math.max(1, featherCount - 1);
                double span = (0.55 + (1.0 - t * 0.55) * 0.85) * scale;
                double rise = (0.55 - t * 1.05 + flap * (1.0 - t * 0.4)) * scale;
                double sweep = (0.30 + t * 0.25 + flap * 0.3) * scale;
                WorldProjection.ScreenPoint tip = proj.project(
                    ox + rightX * (side * span) + backX * sweep,
                    baseY + rise,
                    oz + rightZ * (side * span) + backZ * sweep
                );
                if (!tip.visible()) continue;
                int col = (f == 0 && "Neon".equalsIgnoreCase(wings.style.getValue())) ? accentCol : mainCol;
                drawLine(ctx, Math.round(root.x()), Math.round(root.y()), Math.round(tip.x()), Math.round(tip.y()), col);
                if (prevTip != null) drawLine(ctx, Math.round(prevTip.x()), Math.round(prevTip.y()), Math.round(tip.x()), Math.round(tip.y()), accentCol);
                prevTip = tip;
            }
        }
    }

    private void renderRoolsTrail(DrawContext ctx, RoolsModule rools) {
        if (trailPoints.size() < 2) return;
        int baseColor = rools.color.getValue();
        int total = trailPoints.size(), idx = 0;
        WorldProjection.ScreenPoint prev = null;
        for (Vec3d pt : trailPoints) {
            WorldProjection.ScreenPoint sp = proj.project(pt);
            if (sp.visible() && prev != null && prev.visible()) {
                int col = PurnaTheme.overrideAlpha(baseColor, Math.round(40 + 190 * ((float) idx / total)));
                drawLine(ctx, Math.round(prev.x()), Math.round(prev.y()), Math.round(sp.x()), Math.round(sp.y()), col);
                drawLine(ctx, Math.round(prev.x()), Math.round(prev.y()) + 1, Math.round(sp.x()), Math.round(sp.y()) + 1, col);
            }
            prev = sp;
            idx++;
        }
    }

    private void renderCustomModels(DrawContext ctx, MinecraftClient mc, CustomModelsModule mod, boolean thirdPerson, long now) {
        double scale = mod.scale.getValue();
        CustomModelsModule.ModelPreset preset = mod.model.getValue();
        int accent = switch (preset) {
            case DEMON -> 0xFFE84A5F;
            case RABBIT -> 0xFFF5E6F5;
            case AMOGUS -> 0xFF56C2E8;
            case CYBER -> 0xFFB45AE8;
            default -> 0xFF8DADDE;
        };
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity p)) continue;
            if (mod.onlySelf.isEnabled() && p != mc.player) continue;
            if (p == mc.player && !thirdPerson) continue;
            if (p != mc.player && !isEntityVisible(mc, p)) continue;
            WorldProjection.ScreenPoint head = proj.project(p.getX(), p.getBoundingBox().maxY + 0.14 * scale, p.getZ());
            if (!head.visible()) continue;
            int cx = Math.round(head.x()), cy = Math.round(head.y());
            int r = Math.max(4, Math.round((float) (18.0 * scale / Math.max(1.2, head.depth()))));
            if (preset == CustomModelsModule.ModelPreset.CYBER) {
                int ox = (int) Math.round(Math.cos(now * 0.004) * r);
                PurnaGuiRenderer.drawRoundedBorder(ctx, cx - r, cy - r / 2, r * 2, r, r / 2, PurnaTheme.overrideAlpha(accent, 210));
                PurnaGuiRenderer.drawCircle(ctx, cx + ox, cy, 2, 0xFFFFFFFF);
            } else if (preset == CustomModelsModule.ModelPreset.DEMON) {
                drawLine(ctx, cx - r / 2, cy, cx - r, cy - r, PurnaTheme.overrideAlpha(accent, 225));
                drawLine(ctx, cx + r / 2, cy, cx + r, cy - r, PurnaTheme.overrideAlpha(accent, 225));
            } else if (preset == CustomModelsModule.ModelPreset.RABBIT) {
                PurnaGuiRenderer.drawRoundedRect(ctx, cx - r / 2 - 2, cy - r * 2, 4, r * 2, 2, PurnaTheme.overrideAlpha(accent, 210));
                PurnaGuiRenderer.drawRoundedRect(ctx, cx + r / 2 - 2, cy - r * 2, 4, r * 2, 2, PurnaTheme.overrideAlpha(accent, 210));
            } else {
                PurnaGuiRenderer.drawRoundedBorder(ctx, cx - r, cy - r, r * 2, r * 2, 4, PurnaTheme.overrideAlpha(accent, 200));
            }
        }
    }

    private void renderBlockOverlay(DrawContext ctx, MinecraftClient mc, BlockOverlayModule mod) {
        if (!(mc.crosshairTarget instanceof BlockHitResult bhr) || bhr.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = bhr.getBlockPos();
        drawProjected3DBox(ctx, new Box(pos), mod.color.getValue(), mod.fill.isEnabled(), mod.outline.isEnabled(), mod.alpha.getFloat());
    }

    private void renderPrediction(DrawContext ctx, MinecraftClient mc, PredictionModule pred) {
        int lineColor = PurnaTheme.overrideAlpha(pred.lineColor.getValue(), 220);
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof ProjectileEntity projEnt && !projEnt.isOnGround()) {
                traceArc(ctx, mc, new Vec3d(projEnt.getX(), projEnt.getY(), projEnt.getZ()),
                    projEnt.getVelocity(), 0.03, 0.99, lineColor);
            }
        }
        ItemStack stack = mc.player.getMainHandStack();
        if (stack.isEmpty()) return;
        Item item = stack.getItem();
        double speed = 0.0, gravity = 0.03;
        if (item == Items.ENDER_PEARL && pred.projectiles.isSelected("Pearls")) { speed = 1.5; gravity = 0.03; }
        else if ((item == Items.BOW || item == Items.CROSSBOW) && pred.projectiles.isSelected("Arrows")) { speed = 3.0; gravity = 0.05; }
        else if ((item == Items.SPLASH_POTION || item == Items.LINGERING_POTION) && pred.projectiles.isSelected("Potions")) { speed = 0.5; gravity = 0.05; }
        else if (item == Items.TRIDENT && pred.projectiles.isSelected("Tridents")) { speed = 2.5; gravity = 0.05; }
        if (speed > 0.0) {
            traceArc(ctx, mc, mc.player.getEyePos().add(0, -0.1, 0),
                mc.player.getRotationVector().multiply(speed), gravity, 0.99, lineColor);
        }
    }

    private void traceArc(DrawContext ctx, MinecraftClient mc, Vec3d start, Vec3d vel, double gravity, double drag, int color) {
        Vec3d pos = start, v = vel;
        WorldProjection.ScreenPoint prev = proj.project(pos);
        for (int step = 0; step < 48; step++) {
            Vec3d next = pos.add(v);
            BlockHitResult hit = mc.world.raycast(new RaycastContext(
                pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player
            ));
            boolean landed = hit != null && hit.getType() != HitResult.Type.MISS;
            Vec3d drawPos = landed ? hit.getPos() : next;
            WorldProjection.ScreenPoint sp = proj.project(drawPos);
            if (prev.visible() && sp.visible()) {
                drawLine(ctx, Math.round(prev.x()), Math.round(prev.y()), Math.round(sp.x()), Math.round(sp.y()), color);
            }
            if (landed) {
                if (sp.visible()) PurnaGuiRenderer.drawCircle(ctx, Math.round(sp.x()), Math.round(sp.y()), 4, color);
                break;
            }
            pos = next;
            v = v.multiply(drag).add(0, -gravity, 0);
            prev = sp;
        }
    }

    private void renderParticles(DrawContext ctx, long now) {
        for (VisualParticle p : particles) {
            WorldProjection.ScreenPoint sp = proj.project(p.x, p.y, p.z);
            if (!sp.visible()) continue;
            float fade = 1.0f - (float) (now - p.bornMs) / Math.max(1L, p.lifeMs);
            int col = PurnaTheme.overrideAlpha(p.color, Math.round(235 * Math.max(0f, fade)));
            int sx = Math.round(sp.x()), sy = Math.round(sp.y());
            int r = Math.max(2, Math.round(6.0f / Math.max(1.0f, sp.depth() * 0.4f)));
            if ("Star".equalsIgnoreCase(p.shape) || "Spark".equalsIgnoreCase(p.shape)) {
                ctx.fill(sx - r, sy, sx + r + 1, sy + 1, col);
                ctx.fill(sx, sy - r, sx + 1, sy + r + 1, col);
            } else if ("Heart".equalsIgnoreCase(p.shape)) {
                ctx.fill(sx - 2, sy - 1, sx, sy + 1, col);
                ctx.fill(sx + 1, sy - 1, sx + 3, sy + 1, col);
                ctx.fill(sx - 1, sy, sx + 2, sy + 2, col);
                ctx.fill(sx, sy + 2, sx + 1, sy + 3, col);
            } else {
                PurnaGuiRenderer.drawCircle(ctx, sx, sy, Math.min(4, r), col);
            }
        }
    }

    private void renderHitPoints(DrawContext ctx, long now) {
        for (HitMarker hm : hitMarkers) {
            WorldProjection.ScreenPoint sp = proj.project(hm.x, hm.y, hm.z);
            if (!sp.visible()) continue;
            float t = (float) (now - hm.bornMs) / Math.max(1L, hm.lifeMs);
            int col = PurnaTheme.overrideAlpha(hm.color, Math.round(240 * Math.max(0f, 1f - t)));
            int sx = Math.round(sp.x()), sy = Math.round(sp.y());
            int rad = Math.round(4 + t * 10);
            PurnaGuiRenderer.drawRoundedBorder(ctx, sx - rad, sy - rad, rad * 2, rad * 2, rad, col);
            ctx.fill(sx - 3, sy, sx + 4, sy + 1, col);
            ctx.fill(sx, sy - 3, sx + 1, sy + 4, col);
        }
    }

    private void renderEntityVisuals(DrawContext ctx, MinecraftClient mc, TextRenderer tr, PurnaTheme theme,
                                     BoxModule boxMod, ChamsModule chamsMod, TagsModule tagsMod, ArrowsModule arrowsMod) {
        int sw = proj.getScreenW(), sh = proj.getScreenH();
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !e.isAlive() || e.isRemoved() || e.isInvisible()) continue;
            double dist = mc.player.getEyePos().distanceTo(e.getBoundingBox().getCenter());
            if (dist > 64.0 || !isEntityVisible(mc, e)) continue;

            if (arrowsMod != null && arrowsMod.isEnabled()) {
                boolean validArrow = !arrowsMod.playersOnly.isEnabled() || (e instanceof PlayerEntity);
                if (validArrow && e instanceof LivingEntity) {
                    Vec3d center = e.getBoundingBox().getCenter();
                    WorldProjection.ScreenPoint sp = proj.project(center);
                    boolean offScreen = !sp.visible() || sp.x() < 12 || sp.x() > sw - 12 || sp.y() < 12 || sp.y() > sh - 12;
                    if (offScreen) {
                        float targetYaw = RotationMath.calculateTargetYaw(mc.player.getEyePos(), center);
                        float rel = RotationMath.yawDifference(mc.player.getYaw(), targetYaw);
                        double rad = Math.toRadians(rel - 90.0);
                        int r = arrowsMod.radius.getInt();
                        int ax = Math.round(sw * 0.5f + (float) (Math.cos(rad) * r));
                        int ay = Math.round(sh * 0.5f + (float) (Math.sin(rad) * r));
                        PurnaGuiRenderer.drawCircle(ctx, ax, ay, 4, PurnaTheme.overrideAlpha(arrowsMod.color.getValue(), 220));
                        PurnaGuiRenderer.drawCircle(ctx, ax, ay, 2, 0xFFFFFFFF);
                    }
                }
            }

            float[] bounds = projectEntityRect(e.getBoundingBox());
            if (bounds == null) continue;
            int x1 = Math.round(bounds[0]), y1 = Math.round(bounds[1]);
            int x2 = Math.round(bounds[2]), y2 = Math.round(bounds[3]);
            int bw = Math.max(4, x2 - x1), bh = Math.max(4, y2 - y1);

            if (chamsMod != null && chamsMod.isEnabled() && matchesChamsCategory(e, chamsMod)) {
                PurnaGuiRenderer.drawRoundedRect(ctx, x1, y1, bw, bh, 4,
                    PurnaTheme.overrideAlpha(chamsMod.visibleColor.getValue(), Math.round(chamsMod.alpha.getFloat() * 95f)));
            }

            if (boxMod != null && boxMod.isEnabled() && e instanceof LivingEntity living) {
                int col = PurnaTheme.overrideAlpha(boxMod.color.getValue(), 230);
                String style = boxMod.style.getValue();
                if ("3D".equalsIgnoreCase(style)) drawProjected3DBox(ctx, e.getBoundingBox(), boxMod.color.getValue(), false, true, 0.25f);
                else if ("Corner".equalsIgnoreCase(style)) drawCornerBox(ctx, x1, y1, x2, y2, col);
                else PurnaGuiRenderer.drawRoundedBorder(ctx, x1, y1, bw, bh, 2, col);

                if (boxMod.healthBar.isEnabled()) {
                    float hpRatio = Math.max(0f, Math.min(1f, living.getHealth() / Math.max(1f, living.getMaxHealth())));
                    int barH = Math.round(bh * hpRatio);
                    int hpCol = PurnaTheme.lerpColor(0xFFE85A7C, 0xFF47C992, hpRatio);
                    ctx.fill(x1 - 5, y1, x1 - 2, y2, 0x90000000);
                    ctx.fill(x1 - 4, y2 - barH, x1 - 3, y2, hpCol);
                }
            }

            if (tagsMod != null && tagsMod.isEnabled() && e instanceof LivingEntity living) {
                StringBuilder sb = new StringBuilder(living.getName().getString());
                if (tagsMod.showHealth.isEnabled()) sb.append(String.format(Locale.US, " %.0fHP", living.getHealth() + living.getAbsorptionAmount()));
                if (tagsMod.showDistance.isEnabled()) sb.append(String.format(Locale.US, " %.0fm", dist));
                if (tagsMod.showArmor.isEnabled() && living.getArmor() > 0) sb.append(" [").append(living.getArmor()).append("]");
                String tag = sb.toString();
                int tw = tr.getWidth(tag);
                int pw = tw + 10, ph = 14;
                int px = (x1 + x2) / 2 - pw / 2, py = y1 - ph - 4;
                PurnaGuiRenderer.drawRoundedRect(ctx, px, py, pw, ph, 4, PurnaTheme.withAlpha(theme.getMainBackground(), 0.85f));
                PurnaGuiRenderer.drawRoundedBorder(ctx, px, py, pw, ph, 4, PurnaTheme.withAlpha(theme.getPrimaryAccent(), 0.75f));
                ctx.drawText(tr, tag, px + 5, py + 3, theme.getPrimaryText(), false);
            }
        }
    }

    private void renderTargetEsp(DrawContext ctx, MinecraftClient mc, ModuleManager mm, TargetESPModule mod, long now) {
        Entity target = null;
        AttackAura aura = mm.getModule(AttackAura.class);
        if (aura != null && aura.isEnabled() && aura.getCombatState().hasTarget()) {
            target = aura.getCombatState().getPrimaryTarget();
        } else if (mc.crosshairTarget instanceof EntityHitResult ehr) {
            target = ehr.getEntity();
        }
        if (target == null || !target.isAlive() || target.isRemoved() || target.isInvisible() || !isEntityVisible(mc, target)) return;

        WorldProjection.ScreenPoint sp = proj.project(target.getBoundingBox().getCenter());
        if (!sp.visible()) return;
        int cx = Math.round(sp.x()), cy = Math.round(sp.y());
        int r = Math.max(10, Math.min(48, Math.round(90.0f / Math.max(1.2f, sp.depth()))));
        int col = PurnaTheme.overrideAlpha(mod.color.getValue(), 230);
        double ang = (now * 0.003) * mod.speed.getValue();

        switch (mod.style.getValue()) {
            case "Square" -> PurnaGuiRenderer.drawRoundedBorder(ctx, cx - r, cy - r, r * 2, r * 2, 4, col);
            case "Ring" -> PurnaGuiRenderer.drawRoundedBorder(ctx, cx - r, cy - r, r * 2, r * 2, r, col);
            case "Particles" -> {
                for (int i = 0; i < 6; i++) {
                    double a = ang + (Math.PI * 2.0 * i) / 6.0;
                    PurnaGuiRenderer.drawCircle(ctx, cx + (int) Math.round(Math.cos(a) * r), cy + (int) Math.round(Math.sin(a) * r), 3, col);
                }
            }
            default -> {
                PurnaGuiRenderer.drawRoundedBorder(ctx, cx - r, cy - r, r * 2, r * 2, r, PurnaTheme.overrideAlpha(col, 120));
                for (int i = 0; i < 3; i++) {
                    double a = ang + (Math.PI * 2.0 * i) / 3.0;
                    PurnaGuiRenderer.drawCircle(ctx, cx + (int) Math.round(Math.cos(a) * r), cy + (int) Math.round(Math.sin(a) * r * 0.65), 4, col);
                }
            }
        }
    }

    private void renderShaderHandsAccent(DrawContext ctx, ShaderHandsModule mod, long now) {
        int w = proj.getScreenW(), h = proj.getScreenH();
        int col = "Chroma".equalsIgnoreCase(mod.shaderMode.getValue())
            ? hsvToRgb((float) ((now % 4000L) / 4000.0), 0.72f, 0.95f)
            : mod.tint.getValue();
        int alpha = Math.round(mod.intensity.getFloat() * 52f);
        PurnaGuiRenderer.drawRoundedRect(ctx, w - w / 3, h - h / 3, w / 3 + 12, h / 3 + 12, 24, PurnaTheme.overrideAlpha(col, alpha));
    }

    private boolean isEntityVisible(MinecraftClient mc, Entity target) {
        if (mc.world == null || mc.player == null || target == null) return false;
        BlockHitResult res = mc.world.raycast(new RaycastContext(
            mc.player.getEyePos(), target.getBoundingBox().getCenter(),
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player
        ));
        return res == null || res.getType() == HitResult.Type.MISS;
    }

    private boolean matchesChamsCategory(Entity e, ChamsModule mod) {
        if (e instanceof PlayerEntity) return mod.targets.isSelected("Players");
        if (e instanceof Monster) return mod.targets.isSelected("Hostiles");
        if (e instanceof PassiveEntity) return mod.targets.isSelected("Passives");
        if (e instanceof EndCrystalEntity) return mod.targets.isSelected("Crystals");
        return false;
    }

    private float[] projectEntityRect(Box box) {
        double[] xs = {box.minX, box.maxX}, ys = {box.minY, box.maxY}, zs = {box.minZ, box.maxZ};
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        int visibleCount = 0;
        for (double x : xs) for (double y : ys) for (double z : zs) {
            WorldProjection.ScreenPoint sp = proj.project(x, y, z);
            if (sp.visible()) {
                minX = Math.min(minX, sp.x()); minY = Math.min(minY, sp.y());
                maxX = Math.max(maxX, sp.x()); maxY = Math.max(maxY, sp.y());
                visibleCount++;
            }
        }
        if (visibleCount < 2 || maxX <= minX || maxY <= minY) return null;
        return new float[]{minX, minY, maxX, maxY};
    }

    private void drawProjected3DBox(DrawContext ctx, Box b, int rgb, boolean fill, boolean outline, float fillAlpha) {
        WorldProjection.ScreenPoint[] c = new WorldProjection.ScreenPoint[]{
            proj.project(b.minX, b.minY, b.minZ), proj.project(b.maxX, b.minY, b.minZ),
            proj.project(b.maxX, b.minY, b.maxZ), proj.project(b.minX, b.minY, b.maxZ),
            proj.project(b.minX, b.maxY, b.minZ), proj.project(b.maxX, b.maxY, b.minZ),
            proj.project(b.maxX, b.maxY, b.maxZ), proj.project(b.minX, b.maxY, b.maxZ)
        };
        if (fill) {
            float[] rect = projectEntityRect(b);
            if (rect != null) ctx.fill(Math.round(rect[0]), Math.round(rect[1]), Math.round(rect[2]), Math.round(rect[3]),
                PurnaTheme.overrideAlpha(rgb, Math.round(fillAlpha * 165f)));
        }
        if (outline) {
            int col = PurnaTheme.overrideAlpha(rgb, 235);
            int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
            for (int[] e : edges) {
                if (c[e[0]].visible() && c[e[1]].visible()) {
                    drawLine(ctx, Math.round(c[e[0]].x()), Math.round(c[e[0]].y()), Math.round(c[e[1]].x()), Math.round(c[e[1]].y()), col);
                }
            }
        }
    }

    private void drawCornerBox(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        int lenX = Math.max(4, (x2 - x1) / 4), lenY = Math.max(4, (y2 - y1) / 4);
        ctx.fill(x1, y1, x1 + lenX, y1 + 1, color); ctx.fill(x1, y1, x1 + 1, y1 + lenY, color);
        ctx.fill(x2 - lenX, y1, x2, y1 + 1, color); ctx.fill(x2 - 1, y1, x2, y1 + lenY, color);
        ctx.fill(x1, y2 - 1, x1 + lenX, y2, color); ctx.fill(x1, y2 - lenY, x1 + 1, y2, color);
        ctx.fill(x2 - lenX, y2 - 1, x2, y2, color); ctx.fill(x2 - 1, y2 - lenY, x2, y2, color);
    }

    public static void drawLine(DrawContext ctx, int x0, int y0, int x1, int y1, int color) {
        int steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        if (steps == 0) { ctx.fill(x0, y0, x0 + 1, y0 + 1, color); return; }
        int capped = Math.min(steps, 180);
        float incX = (float) (x1 - x0) / capped, incY = (float) (y1 - y0) / capped;
        float cx = x0, cy = y0;
        for (int i = 0; i <= capped; i++) {
            int ix = Math.round(cx), iy = Math.round(cy);
            ctx.fill(ix, iy, ix + 1, iy + 1, color);
            cx += incX; cy += incY;
        }
    }

    private static int hsvToRgb(float h, float s, float v) {
        float c = v * s, x = c * (1f - Math.abs((h * 6f) % 2f - 1f)), m = v - c;
        float r = 0, g = 0, b = 0;
        switch ((int) (h * 6f) % 6) {
            case 0 -> { r = c; g = x; }
            case 1 -> { r = x; g = c; }
            case 2 -> { g = c; b = x; }
            case 3 -> { g = x; b = c; }
            case 4 -> { r = x; b = c; }
            default -> { r = c; b = x; }
        }
        return (0xFF << 24) | (Math.round((r + m) * 255f) << 16) | (Math.round((g + m) * 255f) << 8) | Math.round((b + m) * 255f);
    }
}
